import Colors from "../constants/colors";
import { useMedicine } from "../contexts/MedicineContext";
import { Stack, useLocalSearchParams, useRouter } from "expo-router";
import { CheckCircle, Clock, Info, Pill } from "lucide-react-native";
import { useState, useEffect } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function EditMedicineScreen() {
  const params = useLocalSearchParams<{ medicineId: string }>();
  const medicineId = Array.isArray(params.medicineId)
    ? params.medicineId[0]
    : params.medicineId;
  const { history, updateMedicine } = useMedicine();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const medicine = history.find((m) => m.id === medicineId);

  const [name, setName] = useState("");
  const [dosageInstructions, setDosageInstructions] = useState("");
  const [effects, setEffects] = useState("");
  const [warnings, setWarnings] = useState("");

  useEffect(() => {
    if (medicine) {
      setName(medicine.name);
      setDosageInstructions(medicine.dosageInstructions);
      setEffects(medicine.effects);
      setWarnings(medicine.warnings);
    }
  }, [medicine]);

  const handleSave = () => {
    if (!medicineId || !medicine) {
      Alert.alert("오류", "약품 정보를 찾을 수 없습니다.");
      return;
    }

    if (!name.trim()) {
      Alert.alert("입력 오류", "약품명을 입력해주세요.");
      return;
    }

    updateMedicine(medicineId, {
      name: name.trim(),
      dosageInstructions: dosageInstructions.trim(),
      effects: effects.trim(),
      warnings: warnings.trim(),
    });

    Alert.alert("저장 완료", "약품 정보가 수정되었습니다.", [
      {
        text: "확인",
        onPress: () => router.back(),
      },
    ]);
  };

  if (!medicine) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>약품 정보를 찾을 수 없습니다</Text>
      </View>
    );
  }

  return (
    <>
      <Stack.Screen
        options={{
          title: "약품 정보 수정",
          headerStyle: {
            backgroundColor: Colors.light.background,
          },
          headerTintColor: Colors.light.text,
        }}
      />
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.content,
            { paddingBottom: insets.bottom + 100 },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.section}>
            <View style={styles.labelRow}>
              <Pill size={18} color={Colors.light.primary} />
              <Text style={styles.label}>약품명</Text>
            </View>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="약품명을 입력하세요"
              placeholderTextColor={Colors.light.textSecondary}
            />
          </View>

          <View style={styles.section}>
            <View style={styles.labelRow}>
              <Clock size={18} color={Colors.light.primary} />
              <Text style={styles.label}>복용 방법</Text>
            </View>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={dosageInstructions}
              onChangeText={setDosageInstructions}
              placeholder="복용 방법을 입력하세요"
              placeholderTextColor={Colors.light.textSecondary}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.section}>
            <View style={styles.labelRow}>
              <CheckCircle size={18} color={Colors.light.success} />
              <Text style={styles.label}>효능</Text>
            </View>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={effects}
              onChangeText={setEffects}
              placeholder="효능을 입력하세요"
              placeholderTextColor={Colors.light.textSecondary}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>

          <View style={styles.section}>
            <View style={styles.labelRow}>
              <Info size={18} color={Colors.light.warning} />
              <Text style={styles.label}>주의사항</Text>
            </View>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={warnings}
              onChangeText={setWarnings}
              placeholder="주의사항을 입력하세요"
              placeholderTextColor={Colors.light.textSecondary}
              multiline
              numberOfLines={4}
              textAlignVertical="top"
            />
          </View>
        </ScrollView>

        <View
          style={[
            styles.footer,
            { paddingBottom: insets.bottom || 12 },
          ]}
        >
          <Pressable style={styles.cancelButton} onPress={() => router.back()}>
            <Text style={styles.cancelButtonText}>취소</Text>
          </Pressable>
          <Pressable style={styles.saveButton} onPress={handleSave}>
            <Text style={styles.saveButtonText}>저장</Text>
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
  },
  errorText: {
    fontSize: 16,
    color: Colors.light.textSecondary,
  },
  scrollView: {
    flex: 1,
  },
  content: {
    padding: 16,
  },
  section: {
    marginBottom: 24,
  },
  labelRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  label: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  input: {
    backgroundColor: Colors.light.card,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: Colors.light.text,
    borderWidth: 1,
    borderColor: Colors.light.border,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
      },
      android: {
        elevation: 1,
      },
      web: {
        boxShadow: "0 1px 2px rgba(0, 0, 0, 0.05)",
      },
    }),
  },
  textArea: {
    minHeight: 100,
    paddingTop: 14,
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    gap: 12,
    paddingHorizontal: 16,
    paddingTop: 12,
    backgroundColor: Colors.light.background,
    borderTopWidth: 1,
    borderTopColor: Colors.light.border,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  cancelButtonText: {
    color: Colors.light.text,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
  saveButton: {
    flex: 1,
    backgroundColor: Colors.light.primary,
    paddingVertical: 16,
    borderRadius: 12,
  },
  saveButtonText: {
    color: Colors.light.card,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
});
