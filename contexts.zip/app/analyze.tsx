import Colors from "../constants/colors";
import { ChatMessage, MedicineInfo, OpenAIMessage, useMedicine } from "../contexts/MedicineContext";

import { Image } from "expo-image";
import { File } from "expo-file-system";
import { useLocalSearchParams, useRouter } from "expo-router";
import {
  Bot,
  CheckCircle,
  Clock,
  Info,
  Pill,
  Send,
  Share2,
  User,
} from "lucide-react-native";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  FlatList,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface AnalysisResult {
  name: string;
  dosageInstructions: string;
  effects: string;
  warnings: string;
}

const ANALYSIS_PROMPT = `이 약품 이미지를 분석하여 다음 정보를 제공해주세요:

1. 약품명: 약의 이름
2. 복용 방법: 복용량, 횟수, 시간 등
3. 효능: 이 약의 효능과 치료 효과
4. 주의사항: 중요한 주의사항, 부작용, 금기사항

명확하고 간결하게 정보를 제공해주세요. 약을 명확히 식별할 수 없다면 알려주세요.

다음 형식으로 응답해주세요:
약품명: [약 이름]
복용방법: [복용 방법]
효능: [효능 및 효과]
주의사항: [주의사항 및 경고]`;

export default function AnalyzeScreen() {
  const params = useLocalSearchParams<{ imageUri?: string; medicineId?: string }>();
  const { imageUri, medicineId } = params;
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(true);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [userInput, setUserInput] = useState("");
  const [conversationHistory, setConversationHistory] = useState<OpenAIMessage[]>([]);
  const { addMedicine, history } = useMedicine();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const flatListRef = useRef<FlatList>(null);
  const inputRef = useRef<TextInput>(null);
  const messagesRef = useRef<ChatMessage[]>([]);

  const activeMedicineId = useMemo(() => (Array.isArray(medicineId) ? medicineId[0] : medicineId), [medicineId]);
  const capturedImageUri = useMemo(() => (Array.isArray(imageUri) ? imageUri[0] : imageUri), [imageUri]);
  const currentMedicine = useMemo(() => {
    if (!activeMedicineId) {
      return undefined;
    }
    return history.find((m) => m.id === activeMedicineId);
  }, [activeMedicineId, history]);
  const resolvedImageUri = useMemo(() => capturedImageUri ?? currentMedicine?.imageUri ?? "", [capturedImageUri, currentMedicine]);

  const addMessage = (message: ChatMessage) => {
    setMessages((prev) => {
      const next = [...prev, message];
      messagesRef.current = next;
      return next;
    });
    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const simulateTypingDelay = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));

  const buildUserImageMessage = async (uri: string): Promise<OpenAIMessage> => {
    console.log("Preparing OpenAI image message with uri:", uri);
    const imageFile = new File(uri);
    const imageInfo = imageFile.info();
    console.log("Image file info:", imageInfo);
    if (!imageInfo.exists) {
      throw new Error("Image file does not exist at provided URI");
    }
    const imageBase64 = await imageFile.base64();
    console.log("Image converted to base64, length:", imageBase64.length);
    return {
      role: "user",
      content: [
        { type: "text", text: ANALYSIS_PROMPT },
        {
          type: "image_url",
          image_url: {
            url: `data:image/jpeg;base64,${imageBase64}`,
          },
        },
      ],
    };
  };

  const buildAssistantSummary = (analysis: AnalysisResult) =>
    `약품명: ${analysis.name}\n복용방법: ${analysis.dosageInstructions}\n효능: ${analysis.effects}\n주의사항: ${analysis.warnings}`;

  const persistConversation = (nextConversation: OpenAIMessage[], nextResult?: AnalysisResult) => {
    if (!activeMedicineId || !currentMedicine) {
      return;
    }
    const fallbackAnalysis: AnalysisResult = nextResult ?? result ?? {
      name: currentMedicine.name,
      dosageInstructions: currentMedicine.dosageInstructions,
      effects: currentMedicine.effects,
      warnings: currentMedicine.warnings,
    };
    const updatedMedicine: MedicineInfo = {
      ...currentMedicine,
      imageUri: resolvedImageUri || currentMedicine.imageUri,
      name: fallbackAnalysis.name,
      dosageInstructions: fallbackAnalysis.dosageInstructions,
      effects: fallbackAnalysis.effects,
      warnings: fallbackAnalysis.warnings,
      chatHistory: messagesRef.current,
      conversationHistory: nextConversation,
    };
    addMedicine(updatedMedicine);
  };

  const analyzeMedicine = async () => {
    if (!capturedImageUri) {
      console.error("No image URI provided");
      return;
    }

    try {
      setIsAnalyzing(true);

      addMessage({
        id: "user-image",
        role: "user",
        content: capturedImageUri,
        type: "image",
      });

      await simulateTypingDelay(500);

      addMessage({
        id: "ai-greeting",
        role: "assistant",
        content: "약 정보를 분석하고 있습니다...",
        type: "text",
      });

      const userImageMessage = await buildUserImageMessage(capturedImageUri);
      setConversationHistory([userImageMessage]);

      const apiKey = "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";

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: [userImageMessage],
          max_tokens: 1000,
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error("OpenAI API Error:", errorData);
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      const responseText = data.choices[0].message.content;

      console.log("AI Response:", responseText);

      const assistantMessage: OpenAIMessage = {
        role: "assistant",
        content: responseText,
      };
      const nextConversation: OpenAIMessage[] = [userImageMessage, assistantMessage];
      setConversationHistory(nextConversation);

      const nameMatch = responseText.match(/약품명:\s*(.+?)(?=\n|$)/i);
      const dosageMatch = responseText.match(
        /복용방법:\s*(.+?)(?=\n(?:효능|주의사항|약품명)|$)/is
      );
      const effectsMatch = responseText.match(
        /효능:\s*(.+?)(?=\n(?:주의사항|약품명|복용방법)|$)/is
      );
      const warningsMatch = responseText.match(/주의사항:\s*(.+?)$/is);

      const analysisResult: AnalysisResult = {
        name: nameMatch?.[1]?.trim() || "알 수 없는 약품",
        dosageInstructions:
          dosageMatch?.[1]?.trim() || "복용 정보를 찾을 수 없습니다",
        effects: effectsMatch?.[1]?.trim() || "효능 정보를 찾을 수 없습니다",
        warnings:
          warningsMatch?.[1]?.trim() || "주의사항 정보를 찾을 수 없습니다",
      };

      setResult(analysisResult);

      await simulateTypingDelay(800);
      addMessage({
        id: "ai-name",
        role: "assistant",
        content: analysisResult.name,
        type: "section",
        icon: "pill",
      });

      await simulateTypingDelay(600);
      addMessage({
        id: "ai-dosage",
        role: "assistant",
        content: `**복용 방법:**\n${analysisResult.dosageInstructions}`,
        type: "section",
        icon: "clock",
      });

      await simulateTypingDelay(600);
      addMessage({
        id: "ai-effects",
        role: "assistant",
        content: `**효능 및 효과:**\n${analysisResult.effects}`,
        type: "section",
        icon: "check",
      });

      await simulateTypingDelay(600);
      addMessage({
        id: "ai-warnings",
        role: "assistant",
        content: `**주의사항 및 경고:**\n${analysisResult.warnings}`,
        type: "section",
        icon: "info",
      });

      await simulateTypingDelay(400);
      addMessage({
        id: "ai-disclaimer",
        role: "assistant",
        content:
          "⚠️ 이 정보는 AI가 생성한 것입니다. 항상 의사나 약사와 상담하세요.",
        type: "text",
      });

      await simulateTypingDelay(400);
      addMessage({
        id: "ai-help",
        role: "assistant",
        content:
          "추가로 궁금한 점이 있으시면 언제든지 질문해주세요! 💬",
        type: "text",
      });

      persistConversation(nextConversation, analysisResult);
    } catch (err) {
      console.error("Error analyzing medicine:", err);
      addMessage({
        id: "ai-error",
        role: "assistant",
        content:
          "죄송합니다. 약품 이미지를 분석할 수 없습니다. 더 선명한 사진으로 다시 시도해주세요.",
        type: "text",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    let isActive = true;

    const hydrateExistingConversation = async () => {
      if (!currentMedicine) {
        return;
      }
      const baseAnalysis: AnalysisResult = {
        name: currentMedicine.name,
        dosageInstructions: currentMedicine.dosageInstructions,
        effects: currentMedicine.effects,
        warnings: currentMedicine.warnings,
      };
      if (isActive) {
        setResult(baseAnalysis);
      }
      const existingMessages = currentMedicine.chatHistory ?? [];
      if (isActive) {
        setMessages(existingMessages);
        messagesRef.current = existingMessages;
      }
      if (currentMedicine.conversationHistory && currentMedicine.conversationHistory.length > 0) {
        if (isActive) {
          setConversationHistory(currentMedicine.conversationHistory);
          setIsAnalyzing(false);
        }
        return;
      }
      if (!resolvedImageUri) {
        if (isActive) {
          setConversationHistory([]);
          setIsAnalyzing(false);
        }
        return;
      }
      try {
        const userMessage = await buildUserImageMessage(resolvedImageUri);
        if (!isActive) {
          return;
        }
        const summaryMessage: OpenAIMessage = {
          role: "assistant",
          content: buildAssistantSummary(baseAnalysis),
        };
        const hydratedHistory: OpenAIMessage[] = [userMessage, summaryMessage];
        setConversationHistory(hydratedHistory);
        persistConversation(hydratedHistory, baseAnalysis);
      } catch (error) {
        console.error("Failed to hydrate conversation history:", error);
        if (isActive) {
          setConversationHistory([]);
        }
      } finally {
        if (isActive) {
          setIsAnalyzing(false);
        }
      }
    };

    if (activeMedicineId) {
      hydrateExistingConversation();
    } else if (capturedImageUri) {
      analyzeMedicine();
    } else {
      setIsAnalyzing(false);
    }

    return () => {
      isActive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeMedicineId, capturedImageUri, currentMedicine, resolvedImageUri]);

  const sendMessage = async () => {
    if (!userInput.trim() || isAnalyzing) return;

    const userMessage = userInput.trim();
    setUserInput("");
    Keyboard.dismiss();

    addMessage({
      id: `user-${Date.now()}`,
      role: "user",
      content: userMessage,
      type: "text",
    });

    const newHistory: OpenAIMessage[] = [
      ...conversationHistory,
      { role: "user", content: userMessage },
    ];

    setConversationHistory(newHistory);
    setIsAnalyzing(true);

    try {
      const apiKey = "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";

      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4o",
          messages: newHistory,
          max_tokens: 1000,
        }),
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error("OpenAI API Error:", errorData);
        throw new Error(`API request failed: ${response.status}`);
      }

      const data = await response.json();
      const responseText = data.choices[0].message.content;

      const assistantMessage: OpenAIMessage = {
        role: "assistant",
        content: responseText,
      };
      const nextHistory: OpenAIMessage[] = [...newHistory, assistantMessage];
      setConversationHistory(nextHistory);

      await simulateTypingDelay(500);
      addMessage({
        id: `assistant-${Date.now()}`,
        role: "assistant",
        content: responseText,
        type: "text",
      });

      persistConversation(nextHistory);
    } catch (err) {
      console.error("Error sending message:", err);
      addMessage({
        id: `error-${Date.now()}`,
        role: "assistant",
        content: "죄송합니다. 메시지를 처리할 수 없습니다. 다시 시도해주세요.",
        type: "text",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const saveToHistory = () => {
    if (!result) return;

    const existingMedicine = activeMedicineId ? history.find((m) => m.id === activeMedicineId) : null;

    const medicine: MedicineInfo = {
      id: activeMedicineId || Date.now().toString(),
      imageUri: resolvedImageUri,
      name: result.name,
      dosageInstructions: result.dosageInstructions,
      effects: result.effects,
      warnings: result.warnings,
      timestamp: existingMedicine?.timestamp || Date.now(),
      chatHistory: messages,
      conversationHistory,
    };

    addMedicine(medicine);
    Alert.alert("저장 완료", "약품 정보가 기록에 저장되었습니다", [
      {
        text: "확인",
        onPress: () => router.push("/history"),
      },
    ]);
  };

  const retake = () => {
    router.back();
  };

  const shareToCommunity = () => {
    if (!result) {
      return;
    }
    if (!resolvedImageUri) {
      Alert.alert("이미지 필요", "이미지 정보를 찾을 수 없습니다. 다시 촬영해주세요.");
      return;
    }
    const summaryTemplate = `${result.name} 복용 요약\n${result.dosageInstructions}`;
    const extractedTemplate = `약품명: ${result.name}\n복용방법: ${result.dosageInstructions}\n효능: ${result.effects}\n주의사항: ${result.warnings}`;
    const defaultTags = ["약품분석", "복용법", "주의사항"];
    console.log("AnalyzeScreen: sharing to community", resolvedImageUri);
    router.push({
      pathname: "/community/upload",
      params: {
        imageUri: encodeURIComponent(resolvedImageUri),
        defaultTitle: encodeURIComponent(result.name),
        defaultSummary: encodeURIComponent(summaryTemplate),
        defaultExtractedText: encodeURIComponent(extractedTemplate),
        defaultTags: encodeURIComponent(defaultTags.join(",")),
      },
    });
  };

  const getIconForType = (icon?: string) => {
    switch (icon) {
      case "pill":
        return <Pill size={18} color={Colors.light.primary} />;
      case "clock":
        return <Clock size={18} color={Colors.light.primary} />;
      case "check":
        return <CheckCircle size={18} color={Colors.light.success} />;
      case "info":
        return <Info size={18} color={Colors.light.warning} />;
      default:
        return null;
    }
  };

  const renderMessage = ({ item }: { item: ChatMessage }) => {
    if (item.role === "user") {
      if (item.type === "image") {
        return (
          <View style={styles.messageContainer}>
            <View style={styles.userMessage}>
              <View style={styles.messageHeader}>
                <View style={styles.avatarUser}>
                  <User size={16} color={Colors.light.card} />
                </View>
                <Text style={styles.messageRole}>나</Text>
              </View>
              <Image source={{ uri: item.content }} style={styles.messageImage} />
            </View>
          </View>
        );
      }
      return (
        <View style={styles.messageContainer}>
          <View style={styles.userMessage}>
            <View style={styles.messageHeader}>
              <View style={styles.avatarUser}>
                <User size={16} color={Colors.light.card} />
              </View>
              <Text style={styles.messageRole}>나</Text>
            </View>
            <Text style={styles.messageText}>{item.content}</Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.messageContainer}>
        <View style={styles.assistantMessage}>
          <View style={styles.messageHeader}>
            <View style={styles.avatarAssistant}>
              <Bot size={16} color={Colors.light.primary} />
            </View>
            <Text style={styles.messageRole}>AI 비서</Text>
          </View>
          {item.type === "section" && item.icon && (
            <View style={styles.sectionIcon}>{getIconForType(item.icon)}</View>
          )}
          <Text
            style={[
              styles.messageText,
              item.icon === "info" && styles.warningText,
            ]}
          >
            {item.content}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
      keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
    >
      <FlatList
        ref={flatListRef}
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={[
          styles.chatContent,
          { paddingTop: insets.top + 16, paddingBottom: result ? 180 : 100 },
        ]}
        showsVerticalScrollIndicator={false}
      />

      {!isAnalyzing && result && (
        <View style={styles.inputContainer}>
          <View style={styles.inputRow}>
            <TextInput
              ref={inputRef}
              style={styles.textInput}
              placeholder="추가 질문을 입력하세요..."
              placeholderTextColor={Colors.light.textSecondary}
              value={userInput}
              onChangeText={setUserInput}
              multiline
              maxLength={500}
              returnKeyType="send"
              onSubmitEditing={sendMessage}
              blurOnSubmit={false}
            />
            <Pressable
              style={[
                styles.sendButton,
                (!userInput.trim() || isAnalyzing) && styles.sendButtonDisabled,
              ]}
              onPress={sendMessage}
              disabled={!userInput.trim() || isAnalyzing}
            >
              <Send
                size={20}
                color={
                  !userInput.trim() || isAnalyzing
                    ? Colors.light.textSecondary
                    : Colors.light.card
                }
              />
            </Pressable>
          </View>
          <View style={styles.actionButtons}>
            <View style={styles.actionRow}>
              <Pressable style={styles.secondaryButton} onPress={retake}>
                <Text style={styles.secondaryButtonText}>다시 촬영</Text>
              </Pressable>
              <Pressable style={styles.primaryButton} onPress={saveToHistory}>
                <Text style={styles.primaryButtonText}>기록에 저장</Text>
              </Pressable>
            </View>
            <Pressable
              testID="share-to-community"
              style={[styles.communityButton, (!resolvedImageUri || !result) && styles.communityButtonDisabled]}
              onPress={shareToCommunity}
              disabled={!resolvedImageUri || !result}
            >
              <Share2
                size={18}
                color={(!resolvedImageUri || !result) ? Colors.light.textSecondary : Colors.light.card}
              />
              <Text style={[styles.communityButtonText, (!resolvedImageUri || !result) && styles.communityButtonTextDisabled]}>
                커뮤니티에 공유
              </Text>
            </Pressable>
          </View>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  chatContent: {
    paddingHorizontal: 16,
  },
  messageContainer: {
    marginBottom: 16,
  },
  userMessage: {
    alignSelf: "flex-end",
    maxWidth: "85%",
    backgroundColor: Colors.light.primary,
    borderRadius: 16,
    padding: 12,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 1px 4px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  assistantMessage: {
    alignSelf: "flex-start",
    maxWidth: "85%",
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 12,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 1px 4px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  messageHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 8,
  },
  avatarUser: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.light.primaryDark,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarAssistant: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.light.primaryLight,
    justifyContent: "center",
    alignItems: "center",
  },
  messageRole: {
    fontSize: 12,
    fontWeight: "600" as const,
    color: Colors.light.textSecondary,
  },
  messageText: {
    fontSize: 15,
    color: Colors.light.text,
    lineHeight: 22,
  },
  warningText: {
    color: Colors.light.warning,
  },
  messageImage: {
    width: "100%",
    aspectRatio: 4 / 3,
    borderRadius: 12,
    backgroundColor: Colors.light.border,
  },
  sectionIcon: {
    marginBottom: 8,
  },
  inputContainer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.light.background,
    borderTopWidth: 1,
    borderTopColor: Colors.light.border,
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 12,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 8,
    marginBottom: 12,
  },
  textInput: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    color: Colors.light.text,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.light.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  sendButtonDisabled: {
    backgroundColor: Colors.light.backgroundSecondary,
  },
  actionButtons: {
    flexDirection: "column",
    gap: 12,
  },
  actionRow: {
    flexDirection: "row",
    gap: 12,
  },
  secondaryButton: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
    paddingVertical: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  secondaryButtonText: {
    color: Colors.light.text,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
  primaryButton: {
    flex: 1,
    backgroundColor: Colors.light.primary,
    paddingVertical: 16,
    borderRadius: 12,
  },
  primaryButtonText: {
    color: Colors.light.card,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
  communityButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    backgroundColor: Colors.light.primary,
    borderRadius: 12,
    paddingVertical: 16,
  },
  communityButtonDisabled: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  communityButtonText: {
    color: Colors.light.card,
    fontSize: 16,
    fontWeight: "700" as const,
  },
  communityButtonTextDisabled: {
    color: Colors.light.textSecondary,
  },
});
