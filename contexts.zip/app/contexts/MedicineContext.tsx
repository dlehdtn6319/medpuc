import createContextHook from "@nkzw/create-context-hook";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useMemo, useState } from "react";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  type?: "image" | "text" | "section";
  icon?: "pill" | "clock" | "check" | "info";
}

export interface MedicineInfo {
  id: string;
  imageUri: string;
  name: string;
  dosageInstructions: string;
  effects: string;
  warnings: string;
  timestamp: number;
  chatHistory?: ChatMessage[];
}

const STORAGE_KEY = "medicine_history";

export const [MedicineProvider, useMedicine] = createContextHook(() => {
  const [history, setHistory] = useState<MedicineInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Failed to load medicine history:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveHistory = async (newHistory: MedicineInfo[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newHistory));
    } catch (error) {
      console.error("Failed to save medicine history:", error);
    }
  };

  const addMedicine = useCallback(
    (medicine: MedicineInfo) => {
      const existingIndex = history.findIndex((m) => m.id === medicine.id);
      const newHistory = existingIndex >= 0 
        ? [...history.slice(0, existingIndex), medicine, ...history.slice(existingIndex + 1)]
        : [medicine, ...history];
      setHistory(newHistory);
      saveHistory(newHistory);
    },
    [history]
  );

  const deleteMedicine = useCallback(
    (id: string) => {
      const newHistory = history.filter((m) => m.id !== id);
      setHistory(newHistory);
      saveHistory(newHistory);
    },
    [history]
  );

  const clearHistory = useCallback(() => {
    setHistory([]);
    saveHistory([]);
  }, []);

  return useMemo(
    () => ({
      history,
      isLoading,
      addMedicine,
      deleteMedicine,
      clearHistory,
    }),
    [history, isLoading, addMedicine, deleteMedicine, clearHistory]
  );
});
