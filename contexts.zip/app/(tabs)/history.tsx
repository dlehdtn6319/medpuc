import Colors from "../../constants/colors";
import { MedicineInfo, useMedicine } from "../../contexts/MedicineContext";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import {
  CheckCircle,
  Clock,
  Edit3,
  Info,
  Pill,
  Trash2,
} from "lucide-react-native";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function HistoryScreen() {
  const { history, isLoading, deleteMedicine, clearHistory } = useMedicine();
  const router = useRouter();

  const handleDelete = (id: string, name: string) => {
    Alert.alert("약품 삭제", `${name}을(를) 기록에서 제거하시겠습니까?`, [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: () => deleteMedicine(id),
      },
    ]);
  };

  const handleClearAll = () => {
    Alert.alert(
      "전체 기록 삭제",
      "모든 약품 기록을 삭제하시겠습니까?",
      [
        { text: "취소", style: "cancel" },
        {
          text: "전체 삭제",
          style: "destructive",
          onPress: clearHistory,
        },
      ]
    );
  };

  const handleViewChat = (id: string) => {
    router.push({
      pathname: "/analyze",
      params: { medicineId: id },
    });
  };

  const handleEdit = (id: string, e?: any) => {
    e?.stopPropagation?.();
    router.push({
      pathname: "/edit-medicine",
      params: { medicineId: id },
    });
  };

  const renderItem = ({ item }: { item: MedicineInfo }) => {
    const date = new Date(item.timestamp);
    const formattedDate = date.toLocaleDateString("ko-KR", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
    const formattedTime = date.toLocaleTimeString("ko-KR", {
      hour: "numeric",
      minute: "2-digit",
    });

    return (
      <Pressable 
        style={styles.card}
        onPress={() => handleViewChat(item.id)}
      >
        <View style={styles.cardHeader}>
          <Image source={{ uri: item.imageUri }} style={styles.thumbnail} />
          <View style={styles.cardHeaderText}>
            <Text style={styles.medicineName} numberOfLines={1}>
              {item.name}
            </Text>
            <Text style={styles.timestamp}>
              {formattedDate} at {formattedTime}
            </Text>
          </View>
          <View style={styles.actionButtons}>
            <Pressable
              style={styles.editButton}
              onPress={(e) => handleEdit(item.id, e)}
            >
              <Edit3 size={18} color={Colors.light.primary} />
            </Pressable>
            <Pressable
              style={styles.deleteButton}
              onPress={(e) => {
                e?.stopPropagation?.();
                handleDelete(item.id, item.name);
              }}
            >
              <Trash2 size={18} color={Colors.light.danger} />
            </Pressable>
          </View>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Clock size={16} color={Colors.light.primary} />
            <Text style={styles.infoLabel}>복용 방법:</Text>
          </View>
          <Text style={styles.infoText} numberOfLines={2}>
            {item.dosageInstructions}
          </Text>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <CheckCircle size={16} color={Colors.light.success} />
            <Text style={styles.infoLabel}>효능:</Text>
          </View>
          <Text style={styles.infoText} numberOfLines={2}>
            {item.effects}
          </Text>
        </View>

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Info size={16} color={Colors.light.warning} />
            <Text style={styles.infoLabel}>주의사항:</Text>
          </View>
          <Text style={styles.infoText} numberOfLines={2}>
            {item.warnings}
          </Text>
        </View>

        <View style={styles.viewChatButton}>
          <Text style={styles.viewChatText}>대화 보기 →</Text>
        </View>
      </Pressable>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
      </View>
    );
  }

  if (history.length === 0) {
    return (
      <View style={styles.emptyContainer}>
        <View style={styles.emptyCard}>
          <View style={styles.emptyIconContainer}>
            <Pill size={48} color={Colors.light.primary} />
          </View>
          <Text style={styles.emptyTitle}>약품 기록 없음</Text>
          <Text style={styles.emptyText}>
            첫 번째 약품을 스캔하여 여기에서 확인하세요
          </Text>
          <Pressable
            style={styles.scanButton}
            onPress={() => router.push("/")}
          >
            <Text style={styles.scanButtonText}>약품 스캔</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <FlatList
        data={history}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
      {history.length > 0 && (
        <View style={styles.footer}>
          <Pressable style={styles.clearButton} onPress={handleClearAll}>
            <Trash2 size={18} color={Colors.light.danger} />
            <Text style={styles.clearButtonText}>전체 기록 삭제</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  centerContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
    padding: 24,
  },
  emptyCard: {
    backgroundColor: Colors.light.card,
    borderRadius: 20,
    padding: 40,
    alignItems: "center",
    maxWidth: 400,
    width: "100%",
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
      },
      android: {
        elevation: 4,
      },
      web: {
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  emptyIconContainer: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: Colors.light.primaryLight,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  emptyTitle: {
    fontSize: 24,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 12,
  },
  emptyText: {
    fontSize: 16,
    color: Colors.light.textSecondary,
    textAlign: "center",
    lineHeight: 24,
    marginBottom: 32,
  },
  scanButton: {
    backgroundColor: Colors.light.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
    width: "100%",
  },
  scanButtonText: {
    color: Colors.light.card,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
  listContent: {
    padding: 16,
  },
  separator: {
    height: 16,
  },
  card: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 3,
      },
      web: {
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.border,
  },
  thumbnail: {
    width: 60,
    height: 60,
    borderRadius: 8,
    backgroundColor: Colors.light.border,
  },
  cardHeaderText: {
    flex: 1,
    marginLeft: 12,
  },
  medicineName: {
    fontSize: 18,
    fontWeight: "600" as const,
    color: Colors.light.text,
    marginBottom: 4,
  },
  timestamp: {
    fontSize: 14,
    color: Colors.light.textSecondary,
  },
  actionButtons: {
    flexDirection: "row",
    gap: 4,
  },
  editButton: {
    padding: 8,
  },
  deleteButton: {
    padding: 8,
  },
  infoSection: {
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 6,
  },
  infoLabel: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  infoText: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    lineHeight: 20,
    paddingLeft: 22,
  },
  viewChatButton: {
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: Colors.light.border,
    alignItems: "center",
  },
  viewChatText: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.primary,
  },
  footer: {
    padding: 16,
    backgroundColor: Colors.light.background,
    borderTopWidth: 1,
    borderTopColor: Colors.light.border,
  },
  clearButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: Colors.light.backgroundSecondary,
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  clearButtonText: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: Colors.light.danger,
  },
});
