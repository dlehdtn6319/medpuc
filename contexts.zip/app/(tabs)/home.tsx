import Colors from "@/constants/colors";
import { useMedicine } from "@/contexts/MedicineContext";
import { generateText } from "@rork-ai/toolkit-sdk";
import {
  AlertCircle,
  Apple,
  Bell,
  Calendar,
  CheckCircle2,
  Clock,
  Pill,
  Plus,
  TrendingUp,
  XCircle,
} from "lucide-react-native";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

interface MedicationReminder {
  id: string;
  medicineId: string;
  medicineName: string;
  days: string[];
  time: string;
  enabled: boolean;
}

interface FoodInteraction {
  medicine: string;
  goodFoods: string[];
  badFoods: string[];
}

const REMINDERS_STORAGE_KEY = "medication_reminders";
const INTERACTIONS_STORAGE_KEY = "food_interactions";

const DAYS = ["월", "화", "수", "목", "금", "토", "일"];

export default function HomeScreen() {
  const { history, isLoading } = useMedicine();
  const [reminders, setReminders] = useState<MedicationReminder[]>([]);
  const [interactions, setInteractions] = useState<FoodInteraction[]>([]);
  const [loadingInteractions, setLoadingInteractions] = useState<string[]>([]);
  const [showReminderModal, setShowReminderModal] = useState(false);
  const [selectedMedicine, setSelectedMedicine] = useState<string | null>(null);
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [selectedTime, setSelectedTime] = useState("09:00");
  const [activeTab, setActiveTab] = useState<"medications" | "reminders" | "patterns">("medications");

  useEffect(() => {
    loadReminders();
    loadInteractions();
  }, []);

  const loadReminders = async () => {
    try {
      const stored = await AsyncStorage.getItem(REMINDERS_STORAGE_KEY);
      if (stored) {
        setReminders(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Failed to load reminders:", error);
    }
  };

  const saveReminders = async (newReminders: MedicationReminder[]) => {
    try {
      await AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(newReminders));
      setReminders(newReminders);
    } catch (error) {
      console.error("Failed to save reminders:", error);
    }
  };

  const loadInteractions = async () => {
    try {
      const stored = await AsyncStorage.getItem(INTERACTIONS_STORAGE_KEY);
      if (stored) {
        setInteractions(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Failed to load interactions:", error);
    }
  };

  const saveInteractions = async (newInteractions: FoodInteraction[]) => {
    try {
      await AsyncStorage.setItem(INTERACTIONS_STORAGE_KEY, JSON.stringify(newInteractions));
      setInteractions(newInteractions);
    } catch (error) {
      console.error("Failed to save interactions:", error);
    }
  };

  const fetchFoodInteractions = useCallback(async (medicineName: string) => {
    setLoadingInteractions((prev) => [...prev, medicineName]);
    try {
      const prompt = `${medicineName} 약품과의 식품 상호작용을 분석해주세요.
      
다음 정보를 **한국어로** 자세하게 제공해주세요:
1. 이 약과 함께 먹으면 좋은 음식 - 각 음식마다 구체적인 효과나 이유를 괄호 안에 간단히 설명해주세요 (예: "물 (간 기능 지원 및 수분 공급)")
2. 피해야 할 음식 - 각 음식마다 피해야 하는 구체적인 이유를 괄호 안에 간단히 설명해주세요 (예: "술 (간독성 위험 증가)")

반드시 한국어로 작성하고 JSON 형식으로 응답:
{
  "goodFoods": ["음식1 (이유)", "음식2 (이유)", "음식3 (이유)"],
  "badFoods": ["음식1 (이유)", "음식2 (이유)", "음식3 (이유)"]
}`;

      const response = await generateText({
        messages: [
          {
            role: "user",
            content: prompt,
          },
        ],
      });

      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const data = JSON.parse(jsonMatch[0]);
        const newInteraction: FoodInteraction = {
          medicine: medicineName,
          goodFoods: data.goodFoods || [],
          badFoods: data.badFoods || [],
        };

        const updatedInteractions = [
          ...interactions.filter((i) => i.medicine !== medicineName),
          newInteraction,
        ];
        saveInteractions(updatedInteractions);
      }
    } catch (error) {
      console.error("Failed to fetch food interactions:", error);
      Alert.alert("Error", "Failed to fetch food interactions");
    } finally {
      setLoadingInteractions((prev) => prev.filter((name) => name !== medicineName));
    }
  }, [interactions]);

  const toggleDay = (day: string) => {
    setSelectedDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const addReminder = () => {
    if (!selectedMedicine || selectedDays.length === 0) {
      Alert.alert("오류", "약품과 최소 하나의 요일을 선택해주세요");
      return;
    }

    const medicine = history.find((m) => m.id === selectedMedicine);
    if (!medicine) return;

    const newReminder: MedicationReminder = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      medicineId: selectedMedicine,
      medicineName: medicine.name,
      days: selectedDays,
      time: selectedTime,
      enabled: true,
    };

    saveReminders([...reminders, newReminder]);
    setShowReminderModal(false);
    setSelectedMedicine(null);
    setSelectedDays([]);
    setSelectedTime("09:00");
  };

  const toggleReminder = useCallback((id: string) => {
    setReminders((prev) => {
      const updated = prev.map((r) =>
        r.id === id ? { ...r, enabled: !r.enabled } : r
      );
      AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  }, []);

  const deleteReminder = useCallback((id: string) => {
    Alert.alert("알림 삭제", "이 알림을 삭제하시겠습니까?", [
      { text: "취소", style: "cancel" },
      {
        text: "삭제",
        style: "destructive",
        onPress: () => {
          setReminders((prev) => {
            const updated = prev.filter((r) => r.id !== id);
            AsyncStorage.setItem(REMINDERS_STORAGE_KEY, JSON.stringify(updated));
            return updated;
          });
        },
      },
    ]);
  }, []);

  const renderMedicationItem = useCallback(
    ({ item }: { item: (typeof history)[0] }) => {
      const interaction = interactions.find((i) => i.medicine === item.name);
      const isLoadingInteraction = loadingInteractions.includes(item.name);

      return (
        <View style={styles.medicationCard}>
          <View style={styles.medicationHeader}>
            <Image source={{ uri: item.imageUri }} style={styles.medicationImage} />
            <View style={styles.medicationInfo}>
              <Text style={styles.medicationName}>{item.name}</Text>
              <Text style={styles.medicationDate}>
                등록일: {new Date(item.timestamp).toLocaleDateString('ko-KR')}
              </Text>
            </View>
          </View>

          {interaction ? (
            <View style={styles.interactionsContainer}>
              <View style={styles.interactionSection}>
                <View style={styles.interactionHeader}>
                  <CheckCircle2 size={18} color={Colors.light.success} />
                  <Text style={styles.interactionTitle}>함께 먹으면 좋은 음식</Text>
                </View>
                <View style={styles.foodList}>
                  {interaction.goodFoods.map((food, index) => (
                    <View key={index} style={styles.foodTag}>
                      <Apple size={14} color={Colors.light.success} />
                      <Text style={styles.foodTagText}>{food}</Text>
                    </View>
                  ))}
                </View>
              </View>

              <View style={styles.interactionSection}>
                <View style={styles.interactionHeader}>
                  <XCircle size={18} color={Colors.light.danger} />
                  <Text style={styles.interactionTitle}>피해야 할 음식</Text>
                </View>
                <View style={styles.foodList}>
                  {interaction.badFoods.map((food, index) => (
                    <View key={index} style={[styles.foodTag, styles.foodTagBad]}>
                      <AlertCircle size={14} color={Colors.light.danger} />
                      <Text style={styles.foodTagText}>{food}</Text>
                    </View>
                  ))}
                </View>
              </View>
            </View>
          ) : (
            <Pressable
              style={styles.loadInteractionsButton}
              onPress={() => fetchFoodInteractions(item.name)}
              disabled={isLoadingInteraction}
            >
              {isLoadingInteraction ? (
                <ActivityIndicator size="small" color={Colors.light.primary} />
              ) : (
                <>
                  <Apple size={18} color={Colors.light.primary} />
                  <Text style={styles.loadInteractionsText}>식품 상호작용 조회</Text>
                </>
              )}
            </Pressable>
          )}
        </View>
      );
    },
    [interactions, loadingInteractions, fetchFoodInteractions]
  );

  const renderReminderItem = useCallback(
    ({ item }: { item: MedicationReminder }) => (
      <View style={styles.reminderCard}>
        <View style={styles.reminderHeader}>
          <View style={styles.reminderIcon}>
            <Pill size={20} color={Colors.light.primary} />
          </View>
          <View style={styles.reminderInfo}>
            <Text style={styles.reminderName}>{item.medicineName}</Text>
            <View style={styles.reminderDetails}>
              <Clock size={14} color={Colors.light.textSecondary} />
              <Text style={styles.reminderTime}>{item.time}</Text>
            </View>
            <View style={styles.daysContainer}>
              {item.days.map((day) => (
                <View key={day} style={styles.dayBadge}>
                  <Text style={styles.dayBadgeText}>{day}</Text>
                </View>
              ))}
            </View>
          </View>
          <Switch
            value={item.enabled}
            onValueChange={() => toggleReminder(item.id)}
            trackColor={{
              false: Colors.light.border,
              true: Colors.light.primary,
            }}
            thumbColor={Colors.light.card}
          />
        </View>
        <Pressable
          style={styles.deleteReminderButton}
          onPress={() => deleteReminder(item.id)}
        >
          <Text style={styles.deleteReminderText}>삭제</Text>
        </Pressable>
      </View>
    ),
    [toggleReminder, deleteReminder]
  );

  const renderPatterns = () => {
    const totalMedications = history.length;
    const medicationsWithReminders = new Set(reminders.map((r) => r.medicineId)).size;
    const activeReminders = reminders.filter((r) => r.enabled).length;

    return (
      <ScrollView style={styles.patternsContainer}>
        <View style={styles.patternCard}>
          <View style={styles.patternHeader}>
            <TrendingUp size={24} color={Colors.light.primary} />
            <Text style={styles.patternTitle}>복용 현황</Text>
          </View>

          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{totalMedications}</Text>
              <Text style={styles.statLabel}>전체 약품</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{activeReminders}</Text>
              <Text style={styles.statLabel}>활성 알림</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{medicationsWithReminders}</Text>
              <Text style={styles.statLabel}>알림 설정됨</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{interactions.length}</Text>
              <Text style={styles.statLabel}>식품 상호작용</Text>
            </View>
          </View>
        </View>

        {history.length > 0 && (
          <View style={styles.patternCard}>
            <Text style={styles.patternTitle}>최근 활동</Text>
            {history.slice(0, 5).map((med) => (
              <View key={med.id} style={styles.activityItem}>
                <Calendar size={16} color={Colors.light.textSecondary} />
                <Text style={styles.activityText}>
                  {med.name} 등록 ({new Date(med.timestamp).toLocaleDateString('ko-KR')})
                </Text>
              </View>
            ))}
          </View>
        )}
      </ScrollView>
    );
  };

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.tabBar}>
        <Pressable
          style={[styles.tab, activeTab === "medications" && styles.tabActive]}
          onPress={() => setActiveTab("medications")}
        >
          <Pill size={20} color={activeTab === "medications" ? Colors.light.primary : Colors.light.textSecondary} />
          <Text style={[styles.tabText, activeTab === "medications" && styles.tabTextActive]}>
            복용 약품
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, activeTab === "reminders" && styles.tabActive]}
          onPress={() => setActiveTab("reminders")}
        >
          <Bell size={20} color={activeTab === "reminders" ? Colors.light.primary : Colors.light.textSecondary} />
          <Text style={[styles.tabText, activeTab === "reminders" && styles.tabTextActive]}>
            알림
          </Text>
        </Pressable>
        <Pressable
          style={[styles.tab, activeTab === "patterns" && styles.tabActive]}
          onPress={() => setActiveTab("patterns")}
        >
          <TrendingUp size={20} color={activeTab === "patterns" ? Colors.light.primary : Colors.light.textSecondary} />
          <Text style={[styles.tabText, activeTab === "patterns" && styles.tabTextActive]}>
            분석
          </Text>
        </Pressable>
      </View>

      {activeTab === "medications" && (
        <FlatList
          data={history}
          keyExtractor={(item) => item.id}
          renderItem={renderMedicationItem}
          contentContainerStyle={styles.listContent}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Pill size={48} color={Colors.light.textSecondary} />
              <Text style={styles.emptyTitle}>등록된 약품이 없습니다</Text>
              <Text style={styles.emptyText}>
                첫 번째 약을 스캔하여 시작하세요
              </Text>
            </View>
          }
        />
      )}

      {activeTab === "reminders" && (
        <>
          <FlatList
            data={reminders}
            keyExtractor={(item) => item.id}
            renderItem={renderReminderItem}
            contentContainerStyle={styles.listContent}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Bell size={48} color={Colors.light.textSecondary} />
                <Text style={styles.emptyTitle}>설정된 알림이 없습니다</Text>
                <Text style={styles.emptyText}>
                  알림을 추가하여 복용 시간을 놓치지 마세요
                </Text>
              </View>
            }
          />
          <Pressable
            style={styles.fab}
            onPress={() => {
              if (history.length === 0) {
                Alert.alert("약품 없음", "먼저 약을 스캔해주세요");
                return;
              }
              setShowReminderModal(true);
            }}
          >
            <Plus size={28} color={Colors.light.card} />
          </Pressable>
        </>
      )}

      {activeTab === "patterns" && renderPatterns()}

      <Modal
        visible={showReminderModal}
        animationType="slide"
        transparent
        onRequestClose={() => setShowReminderModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>복용 알림 추가</Text>

            <Text style={styles.inputLabel}>약품 선택</Text>
            <ScrollView style={styles.medicineList} horizontal showsHorizontalScrollIndicator={false}>
              {history.map((med) => (
                <Pressable
                  key={med.id}
                  style={[
                    styles.medicineOption,
                    selectedMedicine === med.id && styles.medicineOptionSelected,
                  ]}
                  onPress={() => setSelectedMedicine(med.id)}
                >
                  <Text
                    style={[
                      styles.medicineOptionText,
                      selectedMedicine === med.id && styles.medicineOptionTextSelected,
                    ]}
                  >
                    {med.name}
                  </Text>
                </Pressable>
              ))}
            </ScrollView>

            <Text style={styles.inputLabel}>요일 선택</Text>
            <View style={styles.daysGrid}>
              {DAYS.map((day) => (
                <Pressable
                  key={day}
                  style={[
                    styles.dayOption,
                    selectedDays.includes(day) && styles.dayOptionSelected,
                  ]}
                  onPress={() => toggleDay(day)}
                >
                  <Text
                    style={[
                      styles.dayOptionText,
                      selectedDays.includes(day) && styles.dayOptionTextSelected,
                    ]}
                  >
                    {day}
                  </Text>
                </Pressable>
              ))}
            </View>

            <Text style={styles.inputLabel}>시간</Text>
            <TextInput
              style={styles.timeInput}
              value={selectedTime}
              onChangeText={setSelectedTime}
              placeholder="HH:MM"
              placeholderTextColor={Colors.light.textSecondary}
            />

            <View style={styles.modalButtons}>
              <Pressable
                style={[styles.modalButton, styles.modalButtonCancel]}
                onPress={() => setShowReminderModal(false)}
              >
                <Text style={styles.modalButtonTextCancel}>취소</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, styles.modalButtonConfirm]}
                onPress={addReminder}
              >
                <Text style={styles.modalButtonTextConfirm}>알림 추가</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
  },
  tabBar: {
    flexDirection: "row",
    backgroundColor: Colors.light.card,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.border,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    gap: 8,
  },
  tabActive: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.light.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.textSecondary,
  },
  tabTextActive: {
    color: Colors.light.primary,
  },
  listContent: {
    padding: 16,
    gap: 16,
  },
  medicationCard: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  medicationHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  medicationImage: {
    width: 60,
    height: 60,
    borderRadius: 12,
    marginRight: 12,
  },
  medicationInfo: {
    flex: 1,
  },
  medicationName: {
    fontSize: 18,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 4,
  },
  medicationDate: {
    fontSize: 12,
    color: Colors.light.textSecondary,
  },
  interactionsContainer: {
    gap: 12,
  },
  interactionSection: {
    gap: 8,
  },
  interactionHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  interactionTitle: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  foodList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  foodTag: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: Colors.light.successLight,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  foodTagBad: {
    backgroundColor: Colors.light.dangerLight,
  },
  foodTagText: {
    fontSize: 12,
    fontWeight: "500" as const,
    color: Colors.light.text,
  },
  loadInteractionsButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: Colors.light.primaryLight,
  },
  loadInteractionsText: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.primary,
  },
  reminderCard: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 16,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  reminderHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 12,
  },
  reminderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.light.primaryLight,
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  reminderInfo: {
    flex: 1,
  },
  reminderName: {
    fontSize: 16,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 4,
  },
  reminderDetails: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    marginBottom: 8,
  },
  reminderTime: {
    fontSize: 14,
    color: Colors.light.textSecondary,
  },
  daysContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 4,
  },
  dayBadge: {
    backgroundColor: Colors.light.primary,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  dayBadgeText: {
    fontSize: 10,
    fontWeight: "600" as const,
    color: Colors.light.card,
  },
  deleteReminderButton: {
    alignSelf: "flex-start",
    paddingVertical: 4,
  },
  deleteReminderText: {
    fontSize: 12,
    color: Colors.light.danger,
    fontWeight: "600" as const,
  },
  patternsContainer: {
    flex: 1,
  },
  patternCard: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 20,
    margin: 16,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 2px 8px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  patternHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    marginBottom: 20,
  },
  patternTitle: {
    fontSize: 18,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
  statItem: {
    flex: 1,
    minWidth: "45%",
    alignItems: "center",
    padding: 16,
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 12,
  },
  statValue: {
    fontSize: 32,
    fontWeight: "800" as const,
    color: Colors.light.primary,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: Colors.light.textSecondary,
    textAlign: "center",
  },
  activityItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: Colors.light.border,
  },
  activityText: {
    fontSize: 14,
    color: Colors.light.text,
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    textAlign: "center",
  },
  fab: {
    position: "absolute",
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: Colors.light.primary,
    justifyContent: "center",
    alignItems: "center",
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
      },
      android: {
        elevation: 8,
      },
      web: {
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.3)",
      },
    }),
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "flex-end",
  },
  modalContent: {
    backgroundColor: Colors.light.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    maxHeight: "80%",
  },
  modalTitle: {
    fontSize: 22,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 24,
  },
  inputLabel: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.text,
    marginBottom: 8,
    marginTop: 16,
  },
  medicineList: {
    maxHeight: 60,
    marginBottom: 8,
  },
  medicineOption: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
    backgroundColor: Colors.light.backgroundSecondary,
    marginRight: 8,
  },
  medicineOptionSelected: {
    backgroundColor: Colors.light.primary,
  },
  medicineOptionText: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  medicineOptionTextSelected: {
    color: Colors.light.card,
  },
  daysGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  dayOption: {
    flex: 1,
    minWidth: "12%",
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: Colors.light.backgroundSecondary,
    alignItems: "center",
  },
  dayOptionSelected: {
    backgroundColor: Colors.light.primary,
  },
  dayOptionText: {
    fontSize: 12,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  dayOptionTextSelected: {
    color: Colors.light.card,
  },
  timeInput: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    color: Colors.light.text,
  },
  modalButtons: {
    flexDirection: "row",
    gap: 12,
    marginTop: 24,
  },
  modalButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  modalButtonCancel: {
    backgroundColor: Colors.light.backgroundSecondary,
  },
  modalButtonConfirm: {
    backgroundColor: Colors.light.primary,
  },
  modalButtonTextCancel: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  modalButtonTextConfirm: {
    fontSize: 16,
    fontWeight: "600" as const,
    color: Colors.light.card,
  },
});
