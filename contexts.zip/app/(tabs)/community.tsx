import Colors from "../../constants/colors";
import { useMedicine } from "../../contexts/MedicineContext";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { MessageCircle, PlusCircle, Sparkles, Users } from "lucide-react-native";
import { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface RenderItemParams {
  item: {
    id: string;
    imageUri: string;
    title: string;
    summary: string;
    tags: string[];
    createdAt: number;
    comments: { id: string }[];
  };
}

export default function CommunityScreen() {
  const { communityPosts, arePostsLoading, refreshCommunityPosts } = useMedicine();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const orderedPosts = useMemo(() => {
    return [...communityPosts].sort((a, b) => b.createdAt - a.createdAt);
  }, [communityPosts]);

  const onRefresh = useCallback(async () => {
    try {
      console.log("CommunityScreen: refreshing posts");
      setIsRefreshing(true);
      await refreshCommunityPosts();
    } catch (error) {
      console.error("CommunityScreen: failed to refresh", error);
    } finally {
      setIsRefreshing(false);
    }
  }, [refreshCommunityPosts]);

  const handleOpenUpload = useCallback(() => {
    console.log("CommunityScreen: navigating to upload");
    router.push("/community/upload");
  }, [router]);

  const handlePressPost = useCallback(
    (id: string) => {
      console.log("CommunityScreen: opening post", id);
      router.push({ pathname: "/community/[postId]", params: { postId: id } });
    },
    [router]
  );

  const renderEmpty = useCallback(() => {
    if (arePostsLoading) {
      return null;
    }
    return (
      <View style={styles.emptyState}>
        <View style={styles.emptyBadge}>
          <Users size={24} color={Colors.light.primary} />
        </View>
        <Text style={styles.emptyTitle}>아직 게시글이 없어요</Text>
        <Text style={styles.emptySubtitle}>
          첫 번째 약품 정보를 공유하고 커뮤니티 대화를 시작해보세요
        </Text>
        <Pressable testID="create-first-post" style={styles.primaryButton} onPress={handleOpenUpload}>
          <Text style={styles.primaryButtonText}>첫 게시글 올리기</Text>
        </Pressable>
      </View>
    );
  }, [arePostsLoading, handleOpenUpload]);

  const renderItem = useCallback(
    ({ item }: RenderItemParams) => {
      const createdDate = new Date(item.createdAt);
      const timeLabel = createdDate.toLocaleString("ko-KR", {
        month: "short",
        day: "numeric",
        hour: "numeric",
        minute: "2-digit",
      });

      return (
        <Pressable
          testID={`community-post-${item.id}`}
          onPress={() => handlePressPost(item.id)}
          style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}
        >
          <View style={styles.cardHeader}>
            <View style={styles.pillBadge}>
              <Sparkles size={16} color={Colors.light.primary} />
              <Text style={styles.badgeText}>새로운 분석</Text>
            </View>
            <Text style={styles.timestamp}>{timeLabel}</Text>
          </View>
          <Text style={styles.cardTitle} numberOfLines={2}>
            {item.title}
          </Text>
          <Text style={styles.cardSummary} numberOfLines={3}>
            {item.summary}
          </Text>
          <View style={styles.cardMedia}>
            <Image source={{ uri: item.imageUri }} style={styles.cardImage} />
          </View>
          <View style={styles.footerRow}>
            <View style={styles.tagRow}>
              {item.tags.slice(0, 3).map((tag) => (
                <View key={`${item.id}-${tag}`} style={styles.tagChip}>
                  <Text style={styles.tagText}>#{tag}</Text>
                </View>
              ))}
            </View>
            <View style={styles.commentCount}>
              <MessageCircle size={16} color={Colors.light.primary} />
              <Text style={styles.commentText}>{item.comments.length}</Text>
            </View>
          </View>
        </Pressable>
      );
    },
    [handlePressPost]
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top + 8 }] }>
      <LinearGradient colors={["#1E3A8A", "#1D4ED8"]} style={styles.heroSection}>
        <View style={styles.heroContent}>
          <View style={styles.heroIcon}>
            <Sparkles size={28} color={Colors.light.card} />
          </View>
          <View style={styles.heroTextArea}>
            <Text style={styles.heroTitle}>커뮤니티로 지식을 나눠요</Text>
            <Text style={styles.heroSubtitle}>
              분석한 약 정보를 공유하고 다른 사용자와 의견을 나누세요
            </Text>
          </View>
        </View>
        <Pressable testID="open-upload" style={styles.heroButton} onPress={handleOpenUpload}>
          <PlusCircle size={20} color={Colors.light.primary} />
          <Text style={styles.heroButtonText}>게시글 작성</Text>
        </Pressable>
      </LinearGradient>
      {arePostsLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.light.primary} />
        </View>
      ) : (
        <FlatList
          data={orderedPosts}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          ListEmptyComponent={renderEmpty}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={onRefresh}
              tintColor={Colors.light.primary}
              colors={[Colors.light.primary]}
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  heroSection: {
    marginHorizontal: 16,
    marginBottom: 12,
    borderRadius: 24,
    padding: 24,
  },
  heroContent: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    marginBottom: 20,
  },
  heroIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: "rgba(255,255,255,0.18)",
    justifyContent: "center",
    alignItems: "center",
  },
  heroTextArea: {
    flex: 1,
    gap: 6,
  },
  heroTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.light.card,
  },
  heroSubtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.8)",
    lineHeight: 20,
  },
  heroButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: Colors.light.card,
    paddingVertical: 12,
    borderRadius: 14,
  },
  heroButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 24,
    gap: 16,
  },
  card: {
    backgroundColor: Colors.light.card,
    borderRadius: 18,
    padding: 18,
    gap: 12,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOpacity: 0.08,
        shadowRadius: 12,
        shadowOffset: { width: 0, height: 6 },
      },
      android: {
        elevation: 4,
      },
      web: {
        boxShadow: "0 12px 24px rgba(15, 23, 42, 0.08)",
      },
    }),
  },
  cardPressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  pillBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.light.primaryLight,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
  },
  badgeText: {
    fontSize: 12,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  timestamp: {
    fontSize: 12,
    color: Colors.light.textSecondary,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
  },
  cardSummary: {
    fontSize: 14,
    lineHeight: 20,
    color: Colors.light.textSecondary,
  },
  cardMedia: {
    height: 180,
    borderRadius: 16,
    overflow: "hidden",
  },
  cardImage: {
    width: "100%",
    height: "100%",
  },
  footerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  tagRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  tagChip: {
    backgroundColor: Colors.light.backgroundSecondary,
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  tagText: {
    fontSize: 12,
    color: Colors.light.primary,
  },
  commentCount: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  commentText: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  emptyState: {
    padding: 32,
    alignItems: "center",
    justifyContent: "center",
    gap: 20,
  },
  emptyBadge: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: Colors.light.primaryLight,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: Colors.light.text,
  },
  emptySubtitle: {
    fontSize: 15,
    lineHeight: 22,
    color: Colors.light.textSecondary,
    textAlign: "center",
  },
  primaryButton: {
    backgroundColor: Colors.light.primary,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  primaryButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.light.card,
  },
});
