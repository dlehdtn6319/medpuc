import Colors from "@/constants/colors";
import { CameraView, CameraType, useCameraPermissions } from "expo-camera";
import * as FileSystem from "expo-file-system/legacy";
import * as ImagePicker from "expo-image-picker";
import { useRouter } from "expo-router";
import { useIsFocused } from "@react-navigation/native";
import { Camera, FlipHorizontal, Image as ImageIcon, Info } from "lucide-react-native";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";

export default function CameraScreen() {
  const [facing, setFacing] = useState<CameraType>("back");
  const [permission, requestPermission] = useCameraPermissions();
  const [isCapturing, setIsCapturing] = useState<boolean>(false);
  const [cameraReady, setCameraReady] = useState<boolean>(false);
  const cameraRef = useRef<CameraView>(null);
  const router = useRouter();
  const isFocused = useIsFocused();
  const isCapturingRef = useRef<boolean>(false);

  useEffect(() => {
    if (isFocused) {
      console.log("Screen focused -> resetting camera state");
      setCameraReady(false);
      setIsCapturing(false);
      isCapturingRef.current = false;
    }
  }, [isFocused]);

  const pickFromGallery = useCallback(async () => {
    try {
      console.log("Launching image picker...");

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: false,
        quality: 0.8,
      });

      console.log("Image picker result:", result);

      if (result.canceled) {
        console.log("User cancelled image picker");
        return;
      }

      const selectedImage = result.assets[0];
      if (!selectedImage || !selectedImage.uri) {
        throw new Error("Failed to get image from gallery");
      }

      console.log("Selected image:", selectedImage.uri);

      const timestamp = Date.now();
      const fileName = `medicine_${timestamp}.jpg`;
      const permanentUri = `${FileSystem.documentDirectory}${fileName}`;

      console.log("Copying image to permanent location...");

      await FileSystem.copyAsync({
        from: selectedImage.uri,
        to: permanentUri,
      });

      console.log("Image copied successfully to:", permanentUri);

      const savedFileInfo = await FileSystem.getInfoAsync(permanentUri);
      console.log("Saved file info:", savedFileInfo);

      if (!savedFileInfo.exists) {
        throw new Error("Failed to save image to permanent location");
      }

      router.push({
        pathname: "/analyze",
        params: { imageUri: permanentUri },
      });
    } catch (error) {
      console.error("Error picking image:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : "No stack");
      console.error("Error message:", error instanceof Error ? error.message : String(error));

      const errorMessage = error instanceof Error ? error.message : String(error);

      Alert.alert(
        "이미지 선택 오류",
        `이미지를 불러올 수 없습니다. 다시 시도해주세요.\n\n오류: ${errorMessage}`,
        [{ text: "확인" }]
      );
    }
  }, [router]);

  const takePicture = useCallback(async () => {
    if (!isFocused) {
      console.log("Not focused; ignoring capture request");
      return;
    }

    if (isCapturingRef.current) {
      console.log("Already capturing, ignoring request");
      return;
    }

    const cam = cameraRef.current;
    if (!cam) {
      console.log("Camera ref not available");
      Alert.alert("Camera Error", "Camera is not ready. Please try again.");
      return;
    }

    if (!cameraReady) {
      console.log("Camera not ready yet");
      Alert.alert("Camera Not Ready", "Initializing camera. Please try again.");
      return;
    }

    try {
      isCapturingRef.current = true;
      setIsCapturing(true);
      console.log("Starting to take picture...");

      const photo = await cam.takePictureAsync({
        quality: 0.8,
        skipProcessing: false,
      });

      console.log("Photo result:", photo);

      if (!photo || !photo.uri) {
        throw new Error("Failed to capture image");
      }

      console.log("Photo taken successfully:", photo.uri);

      const fileInfo = await FileSystem.getInfoAsync(photo.uri);
      console.log("Photo file info:", fileInfo);

      if (!fileInfo.exists) {
        throw new Error("Photo file does not exist at: " + photo.uri);
      }

      const timestamp = Date.now();
      const fileName = `medicine_${timestamp}.jpg`;
      const permanentUri = `${FileSystem.documentDirectory}${fileName}`;

      console.log("Copying photo to permanent location...");

      await FileSystem.copyAsync({
        from: photo.uri,
        to: permanentUri,
      });

      console.log("Photo copied successfully to:", permanentUri);

      const savedFileInfo = await FileSystem.getInfoAsync(permanentUri);
      console.log("Saved file info:", savedFileInfo);

      if (!savedFileInfo.exists) {
        throw new Error("Failed to save photo to permanent location");
      }

      router.push({
        pathname: "/analyze",
        params: { imageUri: permanentUri },
      });
    } catch (error) {
      console.error("Error taking picture:", error);
      console.error("Error stack:", error instanceof Error ? error.stack : "No stack");
      console.error("Error message:", error instanceof Error ? error.message : String(error));

      const errorMessage = error instanceof Error ? error.message : String(error);

      Alert.alert(
        "사진 촬영 오류",
        `사진을 촬영할 수 없습니다. 다시 시도해주세요.\n\n오류: ${errorMessage}`,
        [{ text: "확인" }]
      );
    } finally {
      await new Promise((resolve) => setTimeout(resolve, 300));
      isCapturingRef.current = false;
      setIsCapturing(false);
    }
  }, [isFocused, cameraReady, router]);

  const toggleCameraFacing = () => {
    setFacing((current) => (current === "back" ? "front" : "back"));
  };

  if (!permission) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.permissionContainer}>
        <View style={styles.permissionCard}>
          <View style={styles.iconContainer}>
            <Camera size={48} color={Colors.light.primary} />
          </View>
          <Text style={styles.permissionTitle}>Camera Access Required</Text>
          <Text style={styles.permissionText}>
            We need access to your camera to scan medicine labels and packaging
          </Text>
          <Pressable
            testID="grant-permission"
            style={styles.permissionButton}
            onPress={requestPermission}
          >
            <Text style={styles.permissionButtonText}>Grant Permission</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {isFocused && (
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing={facing}
          onCameraReady={() => {
            console.log("Camera ready");
            setCameraReady(true);
          }}
          onMountError={(e) => {
            console.error("Camera mount error", e);
            setCameraReady(false);
          }}
        >
        <View style={styles.overlay}>
          <View style={styles.topBar}>
            <View style={styles.infoCard}>
              <Info size={16} color={Colors.light.primary} />
              <Text style={styles.infoText}>Point camera at medicine label</Text>
            </View>
          </View>

          <View style={styles.frameContainer}>
            <View style={styles.frame}>
              <View style={[styles.corner, styles.topLeft]} />
              <View style={[styles.corner, styles.topRight]} />
              <View style={[styles.corner, styles.bottomLeft]} />
              <View style={[styles.corner, styles.bottomRight]} />
            </View>
          </View>

          <View style={styles.bottomBar}>
            <Pressable
              testID="flip-camera"
              style={styles.flipButton}
              onPress={toggleCameraFacing}
              disabled={isCapturing}
            >
              <FlipHorizontal size={28} color={Colors.light.card} />
            </Pressable>

            <Pressable
              testID="take-picture"
              style={[styles.captureButton, isCapturing && styles.captureButtonDisabled]}
              onPress={takePicture}
              disabled={isCapturing || !cameraReady}
            >
              {isCapturing ? (
                <ActivityIndicator size="large" color={Colors.light.card} />
              ) : (
                <View style={styles.captureButtonInner} />
              )}
            </Pressable>

            <Pressable
              testID="pick-from-gallery"
              style={styles.flipButton}
              onPress={pickFromGallery}
              disabled={isCapturing}
            >
              <ImageIcon size={28} color={Colors.light.card} />
            </Pressable>
          </View>
        </View>
        </CameraView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.background,
  },
  permissionContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
    padding: 24,
  },
  permissionCard: {
    backgroundColor: Colors.light.card,
    borderRadius: 20,
    padding: 32,
    alignItems: "center",
    maxWidth: 400,
    width: "100%",
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.1,
        shadowRadius: 12,
      },
      android: {
        elevation: 4,
      },
      web: {
        boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)",
      },
    }),
  },
  iconContainer: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: Colors.light.primaryLight,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 24,
  },
  permissionTitle: {
    fontSize: 24,
    fontWeight: "700" as const,
    color: Colors.light.text,
    marginBottom: 12,
    textAlign: "center",
  },
  permissionText: {
    fontSize: 16,
    color: Colors.light.textSecondary,
    textAlign: "center",
    lineHeight: 24,
    marginBottom: 32,
  },
  permissionButton: {
    backgroundColor: Colors.light.primary,
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
    width: "100%",
  },
  permissionButtonText: {
    color: Colors.light.card,
    fontSize: 16,
    fontWeight: "600" as const,
    textAlign: "center",
  },
  camera: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: "transparent",
  },
  topBar: {
    paddingTop: 60,
    paddingHorizontal: 24,
    alignItems: "center",
  },
  infoCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.95)",
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 24,
    gap: 8,
  },
  infoText: {
    fontSize: 14,
    fontWeight: "600" as const,
    color: Colors.light.text,
  },
  frameContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 40,
  },
  frame: {
    width: "100%",
    aspectRatio: 3 / 4,
    maxWidth: 300,
    maxHeight: 400,
    position: "relative",
  },
  corner: {
    position: "absolute",
    width: 40,
    height: 40,
    borderColor: Colors.light.card,
    borderWidth: 4,
  },
  topLeft: {
    top: 0,
    left: 0,
    borderRightWidth: 0,
    borderBottomWidth: 0,
    borderTopLeftRadius: 8,
  },
  topRight: {
    top: 0,
    right: 0,
    borderLeftWidth: 0,
    borderBottomWidth: 0,
    borderTopRightRadius: 8,
  },
  bottomLeft: {
    bottom: 0,
    left: 0,
    borderRightWidth: 0,
    borderTopWidth: 0,
    borderBottomLeftRadius: 8,
  },
  bottomRight: {
    bottom: 0,
    right: 0,
    borderLeftWidth: 0,
    borderTopWidth: 0,
    borderBottomRightRadius: 8,
  },
  bottomBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 24,
    paddingBottom: 48,
  },
  flipButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "rgba(0, 0, 0, 0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  captureButton: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: Colors.light.card,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 4,
    borderColor: "rgba(255, 255, 255, 0.3)",
  },
  captureButtonDisabled: {
    opacity: 0.6,
  },
  captureButtonInner: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.light.primary,
  },
});
