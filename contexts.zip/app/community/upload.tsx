import Colors from "../../constants/colors";
import { useMedicine } from "../../contexts/MedicineContext";
import { useLocalSearchParams, useRouter } from "expo-router";
import { Flashlight, Hash, ImageUp, Loader2, Save, Sparkles } from "lucide-react-native";
import { useCallback, useMemo, useState } from "react";
import * as ImagePicker from "expo-image-picker";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Image } from "expo-image";

interface UploadParams {
  imageUri?: string;
  defaultTitle?: string;
  defaultSummary?: string;
  defaultExtractedText?: string;
  defaultTags?: string;
}

const splitTags = (value: string) => {
  return value
    .split(/[,#]/)
    .map((item) => item.trim())
    .filter((item) => item.length > 0)
    .map((item) => item.replace(/\s+/g, "-").toLowerCase());
};

export default function CommunityUploadScreen() {
  const params = useLocalSearchParams() as Partial<UploadParams>;
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { addCommunityPost } = useMedicine();

  const decodedImageUri = useMemo(() => (params.imageUri ? decodeURIComponent(params.imageUri) : ""), [params.imageUri]);
  const decodedTitle = useMemo(() => (params.defaultTitle ? decodeURIComponent(params.defaultTitle) : ""), [params.defaultTitle]);
  const decodedSummary = useMemo(() => (params.defaultSummary ? decodeURIComponent(params.defaultSummary) : ""), [params.defaultSummary]);
  const decodedExtracted = useMemo(
    () => (params.defaultExtractedText ? decodeURIComponent(params.defaultExtractedText) : ""),
    [params.defaultExtractedText]
  );
  const initialTags = useMemo(() => {
    if (!params.defaultTags) {
      return [] as string[];
    }
    return splitTags(decodeURIComponent(params.defaultTags));
  }, [params.defaultTags]);

  const [title, setTitle] = useState<string>(decodedTitle);
  const [summary, setSummary] = useState<string>(decodedSummary);
  const [extractedText, setExtractedText] = useState<string>(decodedExtracted);
  const [tags, setTags] = useState<string[]>(initialTags);
  const [tagInput, setTagInput] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [selectedImageUri, setSelectedImageUri] = useState<string>(decodedImageUri);

  const handleAddTag = useCallback(() => {
    const nextTags = splitTags(tagInput);
    if (nextTags.length === 0) {
      return;
    }
    setTags((prev) => {
      const merged = new Set([...prev, ...nextTags]);
      return Array.from(merged).slice(0, 8);
    });
    setTagInput("");
  }, [tagInput]);

  const handleRemoveTag = useCallback((value: string) => {
    setTags((prev) => prev.filter((tag) => tag !== value));
  }, []);

  const pickImageFromGallery = useCallback(async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: "images" as const,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setSelectedImageUri(result.assets[0].uri);
        console.log("Image selected from gallery:", result.assets[0].uri);
      }
    } catch (error) {
      console.error("Error picking image:", error);
      Alert.alert("오류", "갤러리에서 사진을 불러올 수 없습니다.");
    }
  }, []);

  const handleSubmit = useCallback(() => {
    if (!selectedImageUri) {
      Alert.alert("이미지 필요", "커뮤니티에 공유할 사진이 필요합니다.");
      return;
    }
    const trimmedTitle = title.trim();
    const trimmedSummary = summary.trim();
    const trimmedExtracted = extractedText.trim();
    if (!trimmedTitle || !trimmedSummary || !trimmedExtracted) {
      Alert.alert("입력 필요", "제목, 요약, 추출 정보를 모두 입력해주세요.");
      return;
    }
    try {
      setIsSubmitting(true);
      console.log("CommunityUploadScreen: creating post");
      const post = addCommunityPost({
        imageUri: selectedImageUri,
        extractedText: trimmedExtracted,
        title: trimmedTitle,
        summary: trimmedSummary,
        tags,
      });
      Alert.alert("업로드 완료", "커뮤니티에 공유되었습니다!", [
        {
          text: "게시글 보기",
          onPress: () =>
            router.replace({ pathname: "/community/[postId]", params: { postId: post.id } }),
        },
      ]);
    } catch (error) {
      console.error("CommunityUploadScreen: failed to add post", error);
      Alert.alert("업로드 실패", "게시글을 등록할 수 없습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsSubmitting(false);
    }
  }, [addCommunityPost, selectedImageUri, extractedText, router, summary, tags, title]);

  const handleSuggestTag = useCallback(
    (value: string) => {
      setTags((prev) => {
        if (prev.includes(value)) {
          return prev;
        }
        if (prev.length >= 8) {
          return prev;
        }
        return [...prev, value];
      });
    },
    []
  );

  const suggestions = useMemo(() => {
    const base = ["복용법", "주의사항", "효능", "약품리뷰", "AI분석", "부작용", "보관법", "처방전"];
    return base.filter((item) => !tags.includes(item.toLowerCase()))
      .map((item) => item.toLowerCase());
  }, [tags]);

  return (
    <View style={[styles.container, { paddingTop: insets.top + 12, paddingBottom: Math.max(insets.bottom, 24) }] }>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 80 : 0}
      >
        <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          <View style={styles.headerCard}>
            <View style={styles.headerIcon}>
              <Sparkles size={24} color={Colors.light.card} />
            </View>
            <View style={styles.headerTextBlock}>
              <Text style={styles.headerTitle}>커뮤니티에 공유하기</Text>
              <Text style={styles.headerSubtitle}>
                분석 데이터에 제목과 요약을 더해 다른 사용자들과 소통해 보세요
              </Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>사진 프리뷰</Text>
            <Pressable style={styles.previewCard} onPress={pickImageFromGallery}>
              {selectedImageUri ? (
                <Image source={{ uri: selectedImageUri }} style={styles.previewImage} />
              ) : (
                <View style={styles.previewPlaceholder}>
                  <ImageUp size={48} color={Colors.light.textSecondary} />
                  <Text style={styles.previewPlaceholderText}>탭하여 갤러리에서 선택</Text>
                </View>
              )}
            </Pressable>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>제목</Text>
            <TextInput
              testID="upload-title-input"
              style={styles.input}
              placeholder="게시글 제목"
              placeholderTextColor={Colors.light.textSecondary}
              value={title}
              onChangeText={setTitle}
              maxLength={80}
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>요약</Text>
            <TextInput
              testID="upload-summary-input"
              style={[styles.input, styles.multiline]}
              placeholder="핵심 내용을 요약해주세요"
              placeholderTextColor={Colors.light.textSecondary}
              value={summary}
              onChangeText={setSummary}
              multiline
              maxLength={500}
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>약품 정보</Text>
            <TextInput
              testID="upload-extracted-input"
              style={[styles.input, styles.multiline, styles.codeBlock]}
              placeholder="OCR 또는 분석으로 얻은 텍스트를 붙여넣으세요"
              placeholderTextColor={Colors.light.textSecondary}
              value={extractedText}
              onChangeText={setExtractedText}
              multiline
              maxLength={1200}
            />
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionLabel}>태그</Text>
              <View style={styles.sectionCaption}>
                <Hash size={16} color={Colors.light.primary} />
                <Text style={styles.sectionCaptionText}>최대 8개</Text>
              </View>
            </View>
            <View style={styles.tagInputRow}>
              <TextInput
                testID="tag-input"
                style={[styles.input, styles.tagInput]}
                placeholder="#태그 추가 또는 , 로 구분"
                placeholderTextColor={Colors.light.textSecondary}
                value={tagInput}
                onChangeText={setTagInput}
                onSubmitEditing={handleAddTag}
              />
              <Pressable testID="tag-add" style={styles.tagAddButton} onPress={handleAddTag}>
                <Flashlight size={18} color={Colors.light.card} />
              </Pressable>
            </View>
            <View style={styles.tagList}>
              {tags.map((tag) => (
                <Pressable key={tag} style={styles.tagChip} onPress={() => handleRemoveTag(tag)}>
                  <Text style={styles.tagText}>#{tag}</Text>
                </Pressable>
              ))}
            </View>
            {suggestions.length > 0 && (
              <View style={styles.suggestionRow}>
                {suggestions.slice(0, 4).map((item) => (
                  <Pressable key={item} style={styles.suggestionChip} onPress={() => handleSuggestTag(item)}>
                    <Text style={styles.suggestionText}>#{item}</Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <Pressable
            testID="submit-upload"
            style={[styles.submitButton, isSubmitting && styles.submitDisabled]}
            onPress={handleSubmit}
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <Loader2 size={20} color={Colors.light.card} />
            ) : (
              <Save size={20} color={Colors.light.card} />
            )}
            <Text style={styles.submitText}>{isSubmitting ? "업로드 중..." : "커뮤니티에 업로드"}</Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  flex: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 48,
    gap: 24,
  },
  headerCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 20,
    borderRadius: 22,
    backgroundColor: Colors.light.primary,
    gap: 16,
  },
  headerIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: "rgba(255,255,255,0.2)",
    justifyContent: "center",
    alignItems: "center",
  },
  headerTextBlock: {
    flex: 1,
    gap: 6,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.light.card,
  },
  headerSubtitle: {
    fontSize: 14,
    lineHeight: 20,
    color: "rgba(255,255,255,0.85)",
  },
  section: {
    gap: 12,
  },
  sectionLabel: {
    fontSize: 16,
    fontWeight: "700",
    color: Colors.light.text,
  },
  previewCard: {
    height: 220,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: Colors.light.card,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  previewImage: {
    width: "100%",
    height: "100%",
  },
  previewPlaceholder: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    gap: 12,
  },
  previewPlaceholderText: {
    fontSize: 14,
    color: Colors.light.textSecondary,
  },
  input: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: Colors.light.border,
    backgroundColor: Colors.light.card,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: Colors.light.text,
  },
  multiline: {
    minHeight: 120,
    textAlignVertical: "top",
  },
  codeBlock: {
    fontFamily: Platform.select({ ios: "Menlo", android: "monospace", default: "monospace" }),
    lineHeight: 21,
  },
  sectionHeaderRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  sectionCaption: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  sectionCaptionText: {
    fontSize: 12,
    color: Colors.light.primary,
  },
  tagInputRow: {
    flexDirection: "row",
    gap: 12,
  },
  tagInput: {
    flex: 1,
  },
  tagAddButton: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: Colors.light.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  tagList: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  tagChip: {
    borderRadius: 999,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: Colors.light.primaryLight,
  },
  tagText: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  suggestionRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  suggestionChip: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    backgroundColor: Colors.light.background,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  suggestionText: {
    fontSize: 12,
    color: Colors.light.text,
  },
  submitButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    borderRadius: 18,
    paddingVertical: 16,
    backgroundColor: Colors.light.primary,
  },
  submitDisabled: {
    opacity: 0.7,
  },
  submitText: {
    fontSize: 17,
    fontWeight: "700",
    color: Colors.light.card,
  },
});
