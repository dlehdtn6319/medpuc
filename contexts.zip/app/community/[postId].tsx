import Colors from "../../constants/colors";
import { useMedicine } from "../../contexts/MedicineContext";
import { useAuth } from "../../contexts/AuthContext";
import { Image } from "expo-image";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ArrowLeft, Lock, MessageCircle, UserRound, Wand } from "lucide-react-native";
import { useCallback, useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface CommentListItem {
  id: string;
  author: string;
  content: string;
  createdAt: number;
  isAI: boolean;
}

export default function CommunityPostScreen() {
  const { postId } = useLocalSearchParams<{ postId?: string }>();
  const { communityPosts, addCommunityComment } = useMedicine();
  const { user, signIn, isAuthLoading } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [commentText, setCommentText] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isAuthModalVisible, setIsAuthModalVisible] = useState<boolean>(false);
  const [nameInput, setNameInput] = useState<string>("");
  const [isSigningIn, setIsSigningIn] = useState<boolean>(false);

  const post = useMemo(() => {
    return communityPosts.find((item) => item.id === postId);
  }, [communityPosts, postId]);

  const comments = useMemo<CommentListItem[]>(() => {
    if (!post) {
      return [];
    }
    return [...post.comments].sort((a, b) => a.createdAt - b.createdAt);
  }, [post]);

  const handleGoBack = useCallback(() => {
    router.back();
  }, [router]);

  const handleSubmitComment = useCallback(async () => {
    if (!post || !post.id) {
      return;
    }
    const trimmed = commentText.trim();
    if (!trimmed) {
      return;
    }
    if (!user) {
      setIsAuthModalVisible(true);
      return;
    }
    try {
      setIsSubmitting(true);
      console.log("CommunityPostScreen: submitting comment", post.id);
      addCommunityComment(post.id, {
        author: user.name,
        content: trimmed,
        isAI: false,
      });
      setCommentText("");
    } catch (error) {
      console.error("CommunityPostScreen: comment submission failed", error);
      Alert.alert("댓글 오류", "댓글을 등록할 수 없습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsSubmitting(false);
    }
  }, [addCommunityComment, commentText, post, user]);

  const handleSignIn = useCallback(async () => {
    const trimmed = nameInput.trim();
    if (!trimmed) {
      Alert.alert("이름 필요", "댓글을 작성하려면 이름을 입력해주세요.");
      return;
    }
    try {
      setIsSigningIn(true);
      console.log("CommunityPostScreen: signing in for comments");
      await signIn(trimmed);
      setIsAuthModalVisible(false);
      setNameInput("");
    } catch (error) {
      console.error("CommunityPostScreen: sign-in failed", error);
      Alert.alert("로그인 실패", error instanceof Error ? error.message : "로그인에 실패했습니다.");
    } finally {
      setIsSigningIn(false);
    }
  }, [nameInput, signIn]);

  const renderComment = useCallback(({ item }: { item: CommentListItem }) => {
    const date = new Date(item.createdAt);
    const timeLabel = date.toLocaleString("ko-KR", {
      month: "short",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
    });

    return (
      <View style={styles.commentCard}>
        <View style={styles.commentHeader}>
          <View style={[styles.avatar, item.isAI ? styles.avatarAI : styles.avatarUser]}>
            {item.isAI ? (
              <Wand size={16} color={item.isAI ? Colors.light.card : Colors.light.primary} />
            ) : (
              <UserRound size={16} color={item.isAI ? Colors.light.card : Colors.light.primary} />
            )}
          </View>
          <View style={styles.commentMeta}>
            <Text style={styles.commentAuthor}>{item.author}</Text>
            <Text style={styles.commentTime}>{timeLabel}</Text>
          </View>
          {item.isAI && (
            <View style={styles.aiBadge}>
              <Wand size={14} color={Colors.light.primary} />
              <Text style={styles.aiBadgeText}>AI</Text>
            </View>
          )}
        </View>
        <Text style={styles.commentBody}>{item.content}</Text>
      </View>
    );
  }, []);

  if (isAuthLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.light.primary} />
      </View>
    );
  }

  if (!post) {
    return (
      <View style={[styles.loadingContainer, styles.notFoundContainer]}>
        <Text style={styles.notFoundTitle}>게시글을 찾을 수 없습니다</Text>
        <Text style={styles.notFoundSubtitle}>삭제되었거나 잘못된 링크일 수 있습니다</Text>
        <Pressable style={styles.backButton} onPress={handleGoBack} testID="back-from-missing-post">
          <ArrowLeft size={18} color={Colors.light.card} />
          <Text style={styles.backButtonText}>뒤로가기</Text>
        </Pressable>
      </View>
    );
  }

  const header = (
    <View style={styles.headerSection}>
      <View style={styles.imageWrapper}>
        <Image source={{ uri: post.imageUri }} style={styles.heroImage} />
      </View>
      <View style={styles.headerContent}>
        <Text style={styles.postTitle}>{post.title}</Text>
        <Text style={styles.postDate}>
          {new Date(post.createdAt).toLocaleString("ko-KR", {
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit",
          })}
        </Text>
        <View style={styles.tagWrap}>
          {post.tags.map((tag) => (
            <View key={`${post.id}-${tag}`} style={styles.tagChip}>
              <Text style={styles.tagText}>#{tag}</Text>
            </View>
          ))}
        </View>
        <View style={styles.extractedBlock}>
          <Text style={styles.blockTitle}>추출된 정보</Text>
          <Text style={styles.blockBody}>{post.extractedText}</Text>
        </View>
        <View style={styles.summaryBlock}>
          <Text style={styles.blockTitle}>요약</Text>
          <Text style={styles.blockBody}>{post.summary}</Text>
        </View>
      </View>
      <Text style={styles.commentSectionTitle}>댓글 {comments.length}</Text>
    </View>
  );

  return (
    <View style={[styles.container, { paddingTop: insets.top }] }>
      <FlatList
        data={comments}
        keyExtractor={(item) => item.id}
        renderItem={renderComment}
        ListHeaderComponent={header}
        contentContainerStyle={styles.listContainer}
      />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        <View style={[styles.commentComposer, { paddingBottom: Math.max(insets.bottom, 16) }] }>
          <View style={styles.inputWrapper}>
            <TextInput
              testID="comment-input"
              style={styles.commentInput}
              placeholder={user ? "댓글을 입력하세요" : "댓글 작성하려면 로그인하세요"}
              placeholderTextColor={Colors.light.textSecondary}
              value={commentText}
              onChangeText={setCommentText}
              multiline
              editable={!!user}
            />
            {!user && (
              <Pressable style={styles.lockOverlay} onPress={() => setIsAuthModalVisible(true)}>
                <Lock size={18} color={Colors.light.card} />
                <Text style={styles.lockText}>로그인 필요</Text>
              </Pressable>
            )}
          </View>
          <Pressable
            testID="submit-comment"
            style={[styles.sendButton, (!commentText.trim() || isSubmitting || !user) && styles.sendButtonDisabled]}
            onPress={handleSubmitComment}
            disabled={!commentText.trim() || isSubmitting || !user}
          >
            {isSubmitting ? (
              <ActivityIndicator size="small" color={Colors.light.card} />
            ) : (
              <MessageCircle size={18} color={Colors.light.card} />
            )}
          </Pressable>
        </View>
      </KeyboardAvoidingView>

      <Modal transparent visible={isAuthModalVisible} animationType="fade" onRequestClose={() => setIsAuthModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>댓글 작성을 위한 로그인</Text>
            <Text style={styles.modalSubtitle}>커뮤니티에서 사용할 닉네임을 입력해주세요</Text>
            <TextInput
              testID="auth-name-input"
              style={styles.modalInput}
              placeholder="닉네임"
              placeholderTextColor={Colors.light.textSecondary}
              value={nameInput}
              onChangeText={setNameInput}
              autoCapitalize="none"
            />
            <View style={styles.modalActions}>
              <Pressable
                style={[styles.modalButton, styles.modalCancel]}
                onPress={() => setIsAuthModalVisible(false)}
                testID="auth-cancel"
              >
                <Text style={styles.modalCancelText}>취소</Text>
              </Pressable>
              <Pressable
                style={[styles.modalButton, styles.modalConfirm, isSigningIn && styles.modalButtonDisabled]}
                onPress={handleSignIn}
                disabled={isSigningIn}
                testID="auth-confirm"
              >
                {isSigningIn ? (
                  <ActivityIndicator size="small" color={Colors.light.card} />
                ) : (
                  <Text style={styles.modalConfirmText}>로그인</Text>
                )}
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Colors.light.backgroundSecondary,
  },
  notFoundContainer: {
    gap: 16,
    paddingHorizontal: 24,
  },
  notFoundTitle: {
    fontSize: 22,
    fontWeight: "700",
    color: Colors.light.text,
  },
  notFoundSubtitle: {
    fontSize: 15,
    color: Colors.light.textSecondary,
    textAlign: "center",
  },
  backButton: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 14,
    backgroundColor: Colors.light.primary,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: Colors.light.card,
  },
  listContainer: {
    paddingBottom: 160,
  },
  headerSection: {
    paddingHorizontal: 20,
    paddingTop: 24,
    gap: 20,
  },
  imageWrapper: {
    borderRadius: 24,
    overflow: "hidden",
    height: 220,
  },
  heroImage: {
    width: "100%",
    height: "100%",
  },
  headerContent: {
    gap: 18,
  },
  postTitle: {
    fontSize: 24,
    fontWeight: "700",
    color: Colors.light.text,
    lineHeight: 32,
  },
  postDate: {
    fontSize: 13,
    color: Colors.light.textSecondary,
  },
  tagWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  tagChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: Colors.light.primaryLight,
  },
  tagText: {
    fontSize: 12,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  extractedBlock: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 18,
    gap: 10,
  },
  summaryBlock: {
    backgroundColor: Colors.light.card,
    borderRadius: 16,
    padding: 18,
    gap: 10,
    borderWidth: 1,
    borderColor: Colors.light.border,
  },
  blockTitle: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.light.text,
  },
  blockBody: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    lineHeight: 22,
  },
  commentSectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: Colors.light.text,
  },
  commentCard: {
    marginHorizontal: 20,
    marginTop: 16,
    backgroundColor: Colors.light.card,
    borderRadius: 18,
    padding: 16,
    gap: 12,
    ...Platform.select({
      ios: {
        shadowColor: Colors.light.shadow,
        shadowOpacity: 0.06,
        shadowRadius: 10,
        shadowOffset: { width: 0, height: 4 },
      },
      android: {
        elevation: 2,
      },
      web: {
        boxShadow: "0 10px 30px rgba(15, 23, 42, 0.08)",
      },
    }),
  },
  commentHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  avatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
  },
  avatarUser: {
    backgroundColor: Colors.light.primaryLight,
  },
  avatarAI: {
    backgroundColor: "#0F172A",
  },
  commentMeta: {
    flex: 1,
  },
  commentAuthor: {
    fontSize: 14,
    fontWeight: "700",
    color: Colors.light.text,
  },
  commentTime: {
    fontSize: 12,
    color: Colors.light.textSecondary,
  },
  aiBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: Colors.light.primaryLight,
  },
  aiBadgeText: {
    fontSize: 11,
    fontWeight: "600",
    color: Colors.light.primary,
  },
  commentBody: {
    fontSize: 14,
    lineHeight: 22,
    color: Colors.light.text,
  },
  commentComposer: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: Colors.light.background,
    borderTopWidth: 1,
    borderTopColor: Colors.light.border,
    gap: 16,
  },
  inputWrapper: {
    flex: 1,
    position: "relative",
  },
  commentInput: {
    minHeight: 48,
    maxHeight: 120,
    borderRadius: 18,
    padding: 14,
    paddingRight: 48,
    backgroundColor: Colors.light.backgroundSecondary,
    borderWidth: 1,
    borderColor: Colors.light.border,
    fontSize: 14,
    color: Colors.light.text,
  },
  lockOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: "rgba(37, 99, 235, 0.8)",
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    gap: 8,
  },
  lockText: {
    fontSize: 14,
    fontWeight: "600",
    color: Colors.light.card,
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.light.primary,
    justifyContent: "center",
    alignItems: "center",
  },
  sendButtonDisabled: {
    backgroundColor: Colors.light.textSecondary,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(15, 23, 42, 0.55)",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  modalCard: {
    width: "100%",
    maxWidth: 360,
    backgroundColor: Colors.light.card,
    borderRadius: 20,
    padding: 24,
    gap: 16,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "700",
    color: Colors.light.text,
  },
  modalSubtitle: {
    fontSize: 14,
    color: Colors.light.textSecondary,
    lineHeight: 20,
  },
  modalInput: {
    borderRadius: 14,
    borderWidth: 1,
    borderColor: Colors.light.border,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 15,
    color: Colors.light.text,
    backgroundColor: Colors.light.backgroundSecondary,
  },
  modalActions: {
    flexDirection: "row",
    gap: 12,
  },
  modalButton: {
    flex: 1,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  modalCancel: {
    backgroundColor: Colors.light.backgroundSecondary,
  },
  modalConfirm: {
    backgroundColor: Colors.light.primary,
  },
  modalButtonDisabled: {
    opacity: 0.6,
  },
  modalCancelText: {
    fontSize: 15,
    fontWeight: "600",
    color: Colors.light.text,
  },
  modalConfirmText: {
    fontSize: 15,
    fontWeight: "700",
    color: Colors.light.card,
  },
});
