const tintColorLight = "#2563EB";

export default {
  light: {
    text: "#1F2937",
    textSecondary: "#6B7280",
    background: "#FFFFFF",
    backgroundSecondary: "#F9FAFB",
    tint: tintColorLight,
    tabIconDefault: "#9CA3AF",
    tabIconSelected: tintColorLight,
    primary: "#2563EB",
    primaryLight: "#DBEAFE",
    primaryDark: "#1E40AF",
    success: "#10B981",
    successLight: "#D1FAE5",
    warning: "#F59E0B",
    danger: "#EF4444",
    dangerLight: "#FEE2E2",
    border: "#E5E7EB",
    card: "#FFFFFF",
    shadow: "#000000",
  },
};
