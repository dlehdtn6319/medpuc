import createContextHook from "@nkzw/create-context-hook";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useMemo, useState } from "react";

export interface AuthUser {
  id: string;
  name: string;
  avatarColor: string;
}

const AUTH_STORAGE_KEY = "auth_user_v1";
const AVATAR_COLORS = [
  "#2563EB",
  "#7C3AED",
  "#10B981",
  "#F59E0B",
  "#EC4899",
  "#0EA5E9",
  "#F97316",
  "#14B8A6",
];

const generateId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

export const [AuthProvider, useAuth] = createContextHook(() => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);

  useEffect(() => {
    const loadUser = async () => {
      try {
        console.log("AuthContext: loading user from storage");
        const stored = await AsyncStorage.getItem(AUTH_STORAGE_KEY);
        if (stored) {
          const parsed: AuthUser = JSON.parse(stored);
          setUser(parsed);
          console.log("AuthContext: user restored", parsed);
        }
      } catch (error) {
        console.error("AuthContext: failed to load user", error);
      } finally {
        setIsAuthLoading(false);
      }
    };

    loadUser();
  }, []);

  const persistUser = useCallback(async (nextUser: AuthUser | null) => {
    try {
      if (nextUser) {
        await AsyncStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(nextUser));
      } else {
        await AsyncStorage.removeItem(AUTH_STORAGE_KEY);
      }
    } catch (error) {
      console.error("AuthContext: failed to persist user", error);
    }
  }, []);

  const signIn = useCallback(
    async (name: string) => {
      const trimmed = name.trim();
      if (!trimmed) {
        throw new Error("유효한 이름을 입력해주세요");
      }
      const nextUser: AuthUser = {
        id: generateId(),
        name: trimmed,
        avatarColor: AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)],
      };
      console.log("AuthContext: signing in", nextUser);
      setUser(nextUser);
      await persistUser(nextUser);
      return nextUser;
    },
    [persistUser]
  );

  const signOut = useCallback(async () => {
    console.log("AuthContext: signing out");
    setUser(null);
    await persistUser(null);
  }, [persistUser]);

  return useMemo(
    () => ({
      user,
      isAuthLoading,
      signIn,
      signOut,
    }),
    [user, isAuthLoading, signIn, signOut]
  );
});
