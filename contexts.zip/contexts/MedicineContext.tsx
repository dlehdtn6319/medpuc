import createContextHook from "@nkzw/create-context-hook";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useMemo, useState } from "react";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  type?: "image" | "text" | "section";
  icon?: "pill" | "clock" | "check" | "info";
}

export type OpenAIMessageContent =
  | string
  | ({ type: "text"; text: string } | { type: "image_url"; image_url: { url: string } })[];

export interface OpenAIMessage {
  role: "user" | "assistant";
  content: OpenAIMessageContent;
}

export interface MedicineInfo {
  id: string;
  imageUri: string;
  name: string;
  dosageInstructions: string;
  effects: string;
  warnings: string;
  timestamp: number;
  chatHistory?: ChatMessage[];
  conversationHistory?: OpenAIMessage[];
}

export interface MedicineInfoStored {
  id: string;
  imageUri: string;
  name: string;
  dosageInstructions: string;
  effects: string;
  warnings: string;
  timestamp: number;
  hasChat: boolean;
}

export interface CommunityComment {
  id: string;
  postId: string;
  author: string;
  content: string;
  createdAt: number;
  isAI: boolean;
}

export interface CommunityPost {
  id: string;
  imageUri: string;
  extractedText: string;
  title: string;
  summary: string;
  tags: string[];
  createdAt: number;
  comments: CommunityComment[];
}

export interface CreateCommunityPostPayload {
  imageUri: string;
  extractedText: string;
  title: string;
  summary: string;
  tags?: string[];
  aiComment?: Omit<CommunityComment, "id" | "postId" | "createdAt">;
}

const HISTORY_STORAGE_KEY = "medicine_history_v2";
const POSTS_STORAGE_KEY = "medicine_posts_v1";
const CHAT_STORAGE_PREFIX = "medicine_chat_";

const generateId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;

export const [MedicineProvider, useMedicine] = createContextHook(() => {
  const [history, setHistory] = useState<MedicineInfo[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [communityPosts, setCommunityPosts] = useState<CommunityPost[]>([]);
  const [arePostsLoading, setArePostsLoading] = useState<boolean>(true);

  useEffect(() => {
    loadHistory();
    loadCommunityPosts();
  }, []);

  const loadHistory = async () => {
    try {
      const stored = await AsyncStorage.getItem(HISTORY_STORAGE_KEY);
      if (stored) {
        const storedItems: MedicineInfoStored[] = JSON.parse(stored);
        const fullHistory: MedicineInfo[] = await Promise.all(
          storedItems.map(async (item) => {
            if (!item.hasChat) {
              return item;
            }
            try {
              const chatData = await AsyncStorage.getItem(`${CHAT_STORAGE_PREFIX}${item.id}`);
              if (chatData) {
                const parsed = JSON.parse(chatData);
                return {
                  ...item,
                  chatHistory: parsed.chatHistory,
                  conversationHistory: parsed.conversationHistory,
                };
              }
            } catch (err) {
              console.error(`Failed to load chat for ${item.id}:`, err);
            }
            return item;
          })
        );
        setHistory(fullHistory);
      }
    } catch (error) {
      console.error("Failed to load medicine history:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveHistory = async (newHistory: MedicineInfo[]) => {
    try {
      const MAX_HISTORY_ITEMS = 50;
      const limitedHistory = newHistory.slice(0, MAX_HISTORY_ITEMS);
      
      const storedItems: MedicineInfoStored[] = limitedHistory.map((item) => ({
        id: item.id,
        imageUri: item.imageUri,
        name: item.name,
        dosageInstructions: item.dosageInstructions,
        effects: item.effects,
        warnings: item.warnings,
        timestamp: item.timestamp,
        hasChat: !!(item.chatHistory || item.conversationHistory),
      }));

      await AsyncStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(storedItems));

      const saveChatPromises = limitedHistory
        .filter((item) => item.chatHistory || item.conversationHistory)
        .map(async (item) => {
          const chatHistory = item.chatHistory || [];
          const conversationHistory = item.conversationHistory || [];
          
          const trimmedChatHistory = chatHistory.slice(-30);
          const trimmedConversationHistory = conversationHistory.slice(-10).map(msg => {
            if (typeof msg.content === 'string') {
              return msg;
            }
            return {
              ...msg,
              content: msg.content.map(part => {
                if (part.type === 'image_url') {
                  return { type: 'text' as const, text: '[Image]' };
                }
                return part;
              })
            };
          });
          
          await AsyncStorage.setItem(
            `${CHAT_STORAGE_PREFIX}${item.id}`,
            JSON.stringify({
              chatHistory: trimmedChatHistory,
              conversationHistory: trimmedConversationHistory,
            })
          );
        });

      await Promise.all(saveChatPromises);
      
      const allKeys = await AsyncStorage.getAllKeys();
      const storedIds = new Set(limitedHistory.map(item => item.id));
      const orphanedChatKeys = allKeys.filter(
        key => key.startsWith(CHAT_STORAGE_PREFIX) && 
        !storedIds.has(key.replace(CHAT_STORAGE_PREFIX, ''))
      );
      
      if (orphanedChatKeys.length > 0) {
        await AsyncStorage.multiRemove(orphanedChatKeys);
        console.log(`Cleaned up ${orphanedChatKeys.length} orphaned chat records`);
      }
    } catch (error) {
      console.error("Failed to save medicine history:", error);
      if (error instanceof Error && error.message.includes('full')) {
        try {
          console.log('Storage full, attempting emergency cleanup...');
          const allKeys = await AsyncStorage.getAllKeys();
          const chatKeys = allKeys.filter(key => key.startsWith(CHAT_STORAGE_PREFIX));
          
          if (chatKeys.length > 20) {
            const keysToRemove = chatKeys.slice(20);
            await AsyncStorage.multiRemove(keysToRemove);
            console.log(`Emergency cleanup: removed ${keysToRemove.length} chat records`);
          }
        } catch (cleanupError) {
          console.error('Emergency cleanup failed:', cleanupError);
        }
      }
    }
  };

  const loadCommunityPosts = async () => {
    try {
      const stored = await AsyncStorage.getItem(POSTS_STORAGE_KEY);
      if (stored) {
        setCommunityPosts(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Failed to load community posts:", error);
    } finally {
      setArePostsLoading(false);
    }
  };

  const saveCommunityPosts = async (posts: CommunityPost[]) => {
    try {
      await AsyncStorage.setItem(POSTS_STORAGE_KEY, JSON.stringify(posts));
    } catch (error) {
      console.error("Failed to save community posts:", error);
    }
  };

  const addMedicine = useCallback(
    (medicine: MedicineInfo) => {
      const existingIndex = history.findIndex((m) => m.id === medicine.id);
      const newHistory = existingIndex >= 0
        ? [...history.slice(0, existingIndex), medicine, ...history.slice(existingIndex + 1)]
        : [medicine, ...history];
      setHistory(newHistory);
      saveHistory(newHistory);
    },
    [history]
  );

  const updateMedicine = useCallback(
    (id: string, updates: Partial<Pick<MedicineInfo, 'name' | 'dosageInstructions' | 'effects' | 'warnings'>>) => {
      const newHistory = history.map((m) => {
        if (m.id === id) {
          return { ...m, ...updates };
        }
        return m;
      });
      setHistory(newHistory);
      saveHistory(newHistory);
    },
    [history]
  );

  const deleteMedicine = useCallback(
    async (id: string) => {
      const newHistory = history.filter((m) => m.id !== id);
      setHistory(newHistory);
      await saveHistory(newHistory);
      try {
        await AsyncStorage.removeItem(`${CHAT_STORAGE_PREFIX}${id}`);
      } catch (error) {
        console.error(`Failed to delete chat for ${id}:`, error);
      }
    },
    [history]
  );

  const clearHistory = useCallback(async () => {
    try {
      const allKeys = await AsyncStorage.getAllKeys();
      const chatKeys = allKeys.filter((key) => key.startsWith(CHAT_STORAGE_PREFIX));
      await AsyncStorage.multiRemove(chatKeys);
    } catch (error) {
      console.error("Failed to clear chat data:", error);
    }
    setHistory([]);
    await saveHistory([]);
  }, []);

  const addCommunityPost = useCallback(
    (payload: CreateCommunityPostPayload) => {
      const postId = generateId();
      const createdAt = Date.now();
      const nextPost: CommunityPost = {
        id: postId,
        imageUri: payload.imageUri,
        extractedText: payload.extractedText,
        title: payload.title,
        summary: payload.summary,
        tags: payload.tags ?? [],
        createdAt,
        comments: [],
      };

      if (payload.aiComment) {
        const aiComment: CommunityComment = {
          id: generateId(),
          postId,
          author: payload.aiComment.author,
          content: payload.aiComment.content,
          createdAt,
          isAI: payload.aiComment.isAI,
        };
        nextPost.comments = [aiComment];
      }

      setCommunityPosts((prev) => {
        const next = [nextPost, ...prev];
        saveCommunityPosts(next);
        return next;
      });
      return nextPost;
    },
    []
  );

  const addCommunityComment = useCallback(
    (postId: string, comment: Omit<CommunityComment, "id" | "postId" | "createdAt">) => {
      setCommunityPosts((prev) => {
        const next = prev.map((post) => {
          if (post.id !== postId) {
            return post;
          }
          const nextComment: CommunityComment = {
            id: generateId(),
            postId,
            author: comment.author,
            content: comment.content,
            createdAt: Date.now(),
            isAI: comment.isAI,
          };
          return {
            ...post,
            comments: [...post.comments, nextComment],
          };
        });
        saveCommunityPosts(next);
        return next;
      });
    },
    []
  );

  const replaceCommunityComments = useCallback((postId: string, comments: CommunityComment[]) => {
    setCommunityPosts((prev) => {
      const next = prev.map((post) => {
        if (post.id !== postId) {
          return post;
        }
        return {
          ...post,
          comments,
        };
      });
      saveCommunityPosts(next);
      return next;
    });
  }, []);

  const refreshCommunityPosts = useCallback(async () => {
    setArePostsLoading(true);
    await loadCommunityPosts();
  }, []);

  return useMemo(
    () => ({
      history,
      isLoading,
      addMedicine,
      updateMedicine,
      deleteMedicine,
      clearHistory,
      communityPosts,
      arePostsLoading,
      addCommunityPost,
      addCommunityComment,
      replaceCommunityComments,
      refreshCommunityPosts,
    }),
    [
      history,
      isLoading,
      addMedicine,
      updateMedicine,
      deleteMedicine,
      clearHistory,
      communityPosts,
      arePostsLoading,
      addCommunityPost,
      addCommunityComment,
      replaceCommunityComments,
      refreshCommunityPosts,
    ]
  );
});